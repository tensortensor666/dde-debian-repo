#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Dtk6::Widget" for configuration "None"
set_property(TARGET Dtk6::Widget APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Dtk6::Widget PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Concurrent;Qt6::Svg"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdtk6widget.so.6.7.54"
  IMPORTED_SONAME_NONE "libdtk6widget.so.6"
  )

list(APPEND _cmake_import_check_targets Dtk6::Widget )
list(APPEND _cmake_import_check_files_for_Dtk6::Widget "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdtk6widget.so.6.7.54" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

// SPDX-FileCopyrightText: 2021 - 2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

import QtQuick
import QtQuick.Layouts
import org.deepin.dtk 1.0 as D
import org.deepin.dtk.style 1.0 as DS
import org.deepin.dtk.settings 1.0 as Settings
import org.deepin.dtk 1.0

DialogWindow {
    id: control
    enableBehindWindowBlur: false

    property list<Settings.SettingsGroup> groups
    property QtObject config
    property Settings.SettingsContainer container : Settings.SettingsContainer {
        id: settingsContainer
        config: control.config
        navigationTitle: Settings.NavigationTitle {
            width: navigationView.width - navigationView.leftMargin - navigationView.rightMargin
            checked: navigationView.currentIndex === Settings.SettingsGroup.index
            onClicked: navigationView.currentIndex = Settings.SettingsGroup.index
        }
        contentTitle: Settings.ContentTitle {}
        contentBackground: Settings.ContentBackground {}
        groups: control.groups
    }
    property alias navigationView: navigationView
    property alias contentView: contentView

    RowLayout {
        anchors.fill: parent
        spacing: 0

        ScrollView {
            id: navigationBg
            clip: true
            Layout.preferredWidth: DS.Style.settings.navigation.width
            Layout.fillHeight: true

            ListView {
                id: navigationView
                clip: true
                model: container.navigationModel
                leftMargin: DS.Style.settings.navigation.margin
                rightMargin: DS.Style.settings.navigation.margin
                currentIndex: 0
                onCurrentIndexChanged: {
                    contentView.currentIndex = currentIndex
                }
            }
        }

        ScrollView {
            id: contentBg
            Layout.fillWidth: true
            Layout.fillHeight: true
            leftPadding: DS.Style.settings.content.margin
            rightPadding: DS.Style.settings.content.margin
            topPadding: DS.Style.settings.content.margin
            bottomPadding: DS.Style.settings.content.margin
            background: Rectangle {
                anchors.fill: parent
                color: palette.window
                radius: DS.Style.control.radius
                Rectangle {
                    anchors {
                        fill: parent
                        leftMargin: contentBg.leftPadding
                        rightMargin: contentBg.rightPadding
                        topMargin: contentBg.topPadding
                        bottomMargin: contentBg.bottomPadding
                    }
                    color: palette.base
                }
            }

            ListView {
                id: contentView
                model: container.contentModel
                clip: true
                highlightRangeMode: ListView.StrictlyEnforceRange
                currentIndex: 0
                onCurrentIndexChanged: {
                    navigationView.currentIndex = currentIndex
                }
                footer: Item {
                    width: parent.width
                    height: DS.Style.settings.content.resetButtonHeight

                    Button {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.bottom: parent.bottom
                        text: qsTr("Restore Defaults")

                        onClicked: {
                            settingsContainer.resetSettings();
                        }
                    }
                }
            }
        }
    }
}

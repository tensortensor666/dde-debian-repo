set(DDE_APPLICATION_MANAGER_DBUS_API_DIR /usr/share/dde-application-manager/)

#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "DDM::Common" for configuration "None"
set_property(TARGET DDM::Common APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(DDM::Common PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core;Qt6::Network"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libddm-common.so.0.5.0"
  IMPORTED_SONAME_NONE "libddm-common.so.0"
  )

list(APPEND _cmake_import_check_targets DDM::Common )
list(APPEND _cmake_import_check_files_for_DDM::Common "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libddm-common.so.0.5.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

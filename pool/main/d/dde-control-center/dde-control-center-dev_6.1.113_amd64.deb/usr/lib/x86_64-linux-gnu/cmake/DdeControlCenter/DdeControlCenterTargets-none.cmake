#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Dde::Control-Center" for configuration "None"
set_property(TARGET Dde::Control-Center APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Dde::Control-Center PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdde-control-center.so.6.1.113"
  IMPORTED_SONAME_NONE "libdde-control-center.so.6"
  )

list(APPEND _cmake_import_check_targets Dde::Control-Center )
list(APPEND _cmake_import_check_files_for_Dde::Control-Center "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdde-control-center.so.6.1.113" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

include(CMakeFindDependencyMacro)
find_dependency(Dtk6Core REQUIRED)

set (DTK_SETTINGS_TOOLS_EXECUTABLE ${DtkCore_TOOL_DIRS}/dtk-settings)

if (EXISTS ${DTK_SETTINGS_TOOLS_EXECUTABLE})
    set(DTK_SETTINGS_TOOLS_FOUND TRUE)
endif ()

include("${CMAKE_CURRENT_LIST_DIR}/Dtk6SettingsToolsMacros.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/Dtk6ToolsTargets.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/DtkDBusMacros.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/DtkDConfigMacros.cmake")

get_target_property(DTK_XML2CPP Dtk6::Xml2Cpp LOCATION)
get_target_property(DTK_DCONFIG2CPP Dtk6::DConfig2Cpp LOCATION)

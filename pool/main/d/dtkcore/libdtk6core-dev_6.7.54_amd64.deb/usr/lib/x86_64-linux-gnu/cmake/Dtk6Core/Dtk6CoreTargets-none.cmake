#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Dtk6::Core" for configuration "None"
set_property(TARGET Dtk6::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Dtk6::Core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "dbus-1"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdtk6core.so.6.7.54"
  IMPORTED_SONAME_NONE "libdtk6core.so.6"
  )

list(APPEND _cmake_import_check_targets Dtk6::Core )
list(APPEND _cmake_import_check_files_for_Dtk6::Core "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdtk6core.so.6.7.54" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

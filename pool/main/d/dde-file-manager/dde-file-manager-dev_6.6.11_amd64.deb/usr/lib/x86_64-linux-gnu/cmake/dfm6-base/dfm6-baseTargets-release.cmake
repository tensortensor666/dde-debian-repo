#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "DFM6::dfm6-base" for configuration "Release"
set_property(TARGET DFM6::dfm6-base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(DFM6::dfm6-base PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "libappimage;Qt6::WaylandClient"
  IMPORTED_LOCATION_RELEASE "/usr/lib/x86_64-linux-gnu/libdfm6-base.so.6.6.11"
  IMPORTED_SONAME_RELEASE "libdfm6-base.so.1"
  )

list(APPEND _cmake_import_check_targets DFM6::dfm6-base )
list(APPEND _cmake_import_check_files_for_DFM6::dfm6-base "/usr/lib/x86_64-linux-gnu/libdfm6-base.so.6.6.11" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

set(dfm6-framework_INCLUDE_DIR /usr/include)
set(dfm6-framework_LIBRARIES dfm6-framework)
include_directories("${dfm6-framework_INCLUDE_DIR}")

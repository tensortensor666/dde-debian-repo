include(CMakeFindDependencyMacro)

# 添加必要的依赖
find_dependency(dfm6-io)
find_dependency(dfm6-mount)
find_dependency(dfm6-burn)
find_dependency(Qt6 COMPONENTS Core Widgets Gui Concurrent DBus Sql Network)
find_dependency(Dtk6 COMPONENTS Core Widget Gui)

# 添加 PkgConfig 依赖
find_dependency(PkgConfig)
pkg_check_modules(gio REQUIRED IMPORTED_TARGET gio-unix-2.0)
pkg_check_modules(mount REQUIRED IMPORTED_TARGET mount)
pkg_search_module(X11 REQUIRED IMPORTED_TARGET x11)


set(dfm6-base_INCLUDE_DIR /usr/include)
set(dfm6-base_LIBRARIES dfm6-base)

if(NOT TARGET dfm6-base)
    include("${CMAKE_CURRENT_LIST_DIR}/dfm6-baseTargets.cmake")
endif()

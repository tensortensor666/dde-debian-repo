set(dfm-extension_INCLUDE_DIR /usr/include)
set(dfm-extension_LIBRARIES dfm-extension)
include_directories("${dfm-extension_INCLUDE_DIR}")

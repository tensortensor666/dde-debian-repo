/*
 * This an unstable interface of wlroots. No guarantees are made regarding the
 * future consistency of this API.
 */
#ifndef WLR_USE_UNSTABLE
#error "Add -DWLR_USE_UNSTABLE to enable unstable wlroots features"
#endif

#ifndef WLR_TYPES_WLR_LINUX_DRM_SYNCOBJ_V1_H
#define WLR_TYPES_WLR_LINUX_DRM_SYNCOBJ_V1_H

#include <stdbool.h>
#include <wayland-server-core.h>
#include <wlr/util/addon.h>

struct wlr_buffer;
struct wlr_surface;

struct wlr_linux_drm_syncobj_surface_v1_state {
	struct wlr_drm_syncobj_timeline *acquire_timeline;
	uint64_t acquire_point;

	struct {
		bool committed;
		struct wlr_drm_syncobj_timeline *release_timeline;
		uint64_t release_point;
		struct wlr_drm_syncobj_merger *release_merger;
	} WLR_PRIVATE;
};

struct wlr_linux_drm_syncobj_manager_v1 {
	struct wl_global *global;

	struct {
		int drm_fd;

		struct wl_listener display_destroy;
	} WLR_PRIVATE;
};

/**
 * Advertise explicit synchronization support to clients.
 *
 * The compositor must be prepared to handle fences coming from clients and to
 * send release fences correctly. In particular, both the renderer and the
 * backend need to support explicit synchronization.
 */
struct wlr_linux_drm_syncobj_manager_v1 *wlr_linux_drm_syncobj_manager_v1_create(
	struct wl_display *display, uint32_t version, int drm_fd);

/**
 * Destroy the protocol manager and remove its globals.
 *
 * If destroy_global_safe is true, remove globals now and defer their
 * destruction; otherwise destroy them immediately.
 *
 * All client objects using this manager must be destroyed before calling this
 * function. The manager is also destroyed automatically when the display is
 * destroyed.
 */
void wlr_linux_drm_syncobj_manager_v1_destroy(struct wlr_linux_drm_syncobj_manager_v1 *manager,
	bool destroy_global_safe);

struct wlr_linux_drm_syncobj_surface_v1_state *wlr_linux_drm_syncobj_v1_get_surface_state(
	struct wlr_surface *surface);

/**
 * Signal the release point when wlr_buffer.events.release is emitted.
 *
 * Compositors unwilling to track fine-grained commit release can call this
 * helper on surface commit.
 */
bool wlr_linux_drm_syncobj_v1_state_signal_release_with_buffer(
	struct wlr_linux_drm_syncobj_surface_v1_state *state, struct wlr_buffer *buffer);

/**
 * Register a release point for buffer usage.
 *
 * This function may be called multiple times for the same commit. The client's
 * release point will be signalled when all registered points are signalled, and
 * a new buffer has been committed.
 *
 * Because the given release point may not be materialized, a wl_event_loop must
 * be supplied to schedule a wait internally, if needed
 */
bool wlr_linux_drm_syncobj_v1_state_add_release_point(
	struct wlr_linux_drm_syncobj_surface_v1_state *state,
	struct wlr_drm_syncobj_timeline *release_timeline, uint64_t release_point,
	struct wl_event_loop *event_loop);

#endif

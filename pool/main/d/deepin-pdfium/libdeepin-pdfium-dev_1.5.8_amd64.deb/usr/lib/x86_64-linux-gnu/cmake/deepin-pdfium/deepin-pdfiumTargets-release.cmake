#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "deepin-pdfium::deepin-pdfium" for configuration "Release"
set_property(TARGET deepin-pdfium::deepin-pdfium APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(deepin-pdfium::deepin-pdfium PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Core;Qt6::Gui"
  IMPORTED_LOCATION_RELEASE "/usr/lib/x86_64-linux-gnu/libdeepin-pdfium.so.1.5.8"
  IMPORTED_SONAME_RELEASE "libdeepin-pdfium.so.1"
  )

list(APPEND _cmake_import_check_targets deepin-pdfium::deepin-pdfium )
list(APPEND _cmake_import_check_files_for_deepin-pdfium::deepin-pdfium "/usr/lib/x86_64-linux-gnu/libdeepin-pdfium.so.1.5.8" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

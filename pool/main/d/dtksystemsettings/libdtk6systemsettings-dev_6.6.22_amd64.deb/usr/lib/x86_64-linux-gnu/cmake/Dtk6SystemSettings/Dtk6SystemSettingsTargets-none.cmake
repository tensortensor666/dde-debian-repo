#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Dtk6::SystemSettings" for configuration "None"
set_property(TARGET Dtk6::SystemSettings APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Dtk6::SystemSettings PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdtk6systemsettings.so.6.6.22"
  IMPORTED_SONAME_NONE "libdtk6systemsettings.so.6"
  )

list(APPEND _cmake_import_check_targets Dtk6::SystemSettings )
list(APPEND _cmake_import_check_files_for_Dtk6::SystemSettings "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdtk6systemsettings.so.6.6.22" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

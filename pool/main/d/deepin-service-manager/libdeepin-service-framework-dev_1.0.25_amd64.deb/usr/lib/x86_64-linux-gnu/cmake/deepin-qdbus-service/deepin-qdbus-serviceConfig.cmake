set(deepin-qdbus-service_INCLUDE_DIR /usr/include/deepin-qdbus-service)
set(deepin-qdbus-service_LIBRARIES deepin-qdbus-service)
include_directories("${deepin-qdbus-service_INCLUDE_DIR}")


// SPDX-FileCopyrightText: 2022-2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef _DMR_UTILS_H
#define _DMR_UTILS_H

#include <QtGui>

namespace dmr {
namespace utils {
static unsigned int  DAYSECONDS = 86400;
void ShowInFileManager(const QString &path);
bool CompareNames(const QString &fileName1, const QString &fileName2);
bool first_check_wayland_env();
bool check_wayland_env();
void set_wayland(bool);
bool IsNamesSimilar(const QString &s1, const QString &s2);
QFileInfoList FindSimilarFiles(const QFileInfo &fi);
QString FastFileHash(const QFileInfo &fi);
QString FullFileHash(const QFileInfo &fi);

QPixmap MakeRoundedPixmap(QPixmap pm, qreal rx, qreal ry, int rotation = 0);
QPixmap MakeRoundedPixmap(QSize sz, QPixmap pm, qreal rx, qreal ry, qint64 time);

QImage LoadHiDPIImage(const QString &filename);
QPixmap LoadHiDPIPixmap(const QString &filename);

uint32_t InhibitStandby();
void UnInhibitStandby(uint32_t cookie);

uint32_t InhibitPower();
void UnInhibitPower(uint32_t cookie);

void MoveToCenter(QWidget *w);

QString Time2str(qint64 seconds);
QString videoIndex2str(int);
QString audioIndex2str(int);
QString subtitleIndex2str(int);

/**
 * @brief 检查截屏路径是否存在 cppcheck在使用
 */
bool ValidateScreenshotPath(const QString &path);

QString ElideText(const QString &text, const QSize &size,
                  QTextOption::WrapMode wordWrap, const QFont &font,
                  Qt::TextElideMode mode, int lineHeight, int lastLineWidth);
/**
 * @brief 获取播放配置
 * @param 配置文件path
 * @param 配置保存的map
 */
void getPlayProperty(const char *path, QMap<QString, QString> *&proMap);
/**
 * @brief run cmd
 * @param command filter
 */
QStringList runPipeProcess(const QString &command, const QString &filter);
void switchToDefaultSink();

/**
 * @brief 检测是否存在Sietium显卡
 * @return 如果存在Sietium显卡返回true，否则返回false
 */
bool isSietiumGPUPresent();

/**
 * @brief 检测是否存在jjw显卡
 * @return 如果存在jjw显卡返回true，否则返回false
 */
bool isJjwGPUPresent();

/**
 * @brief 检测是否存在凌久微(ljmcore)显卡
 * @return 如果存在凌久微显卡返回true，否则返回false
 */
bool isLjmGPUPresent();

/**
 * @brief 检测是否存在Fantasy显卡
 * @return 如果存在Fantasy显卡返回true，否则返回false
 */
bool isFantasyGPUPresent();

/**
 * @brief 获取jjw显卡设备路径
 * @return 返回存在的设备路径，如果都不存在则返回空字符串
 */
QString getJjwGPUPath();

/**
 * @brief 获取gpuinfo数据库为当前GPU配置的hwdec interop
 * @return interop值（如"vaapi-egl"），未匹配到或库不可用时返回空字符串
 */
QString gpuInfoInterop();
/**
 * @brief 检测是否在玲珑环境
 * @return 如果是玲珑环境返回true，否则返回false
 */
bool IsLinglongEnvironment();

/**
 * @brief 将路径转换为玲珑环境播放路径（添加 /run/host/rootfs 前缀）
 * @param path 原始路径
 * @return 转换后的路径
 */
QString ConvertLinglongPathForPlayback(const QString &path);

/**
 * @brief 将路径转换为玲珑环境文件管理器路径（去掉 /run/host/rootfs 前缀）
 * @param path 原始路径
 * @return 转换后的路径
 */
QString ConvertLinglongPathForFM(const QString &path);
}

}

#endif /* ifndef _DMR_UTILS_H */

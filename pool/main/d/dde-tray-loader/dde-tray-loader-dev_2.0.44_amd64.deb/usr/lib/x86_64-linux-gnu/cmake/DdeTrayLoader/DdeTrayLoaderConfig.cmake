set(DDE_TRAY_LOADER_INCLUDE_DIR /usr/include/dde-dock)
set(DDE_TRAY_LOADER_PROTOCOL /usr/include/dde-tray-loader/protocol/plugin-manager-v1.xml)
include_directories("${DDE_TRAY_LOADER_INCLUDE_DIR}")

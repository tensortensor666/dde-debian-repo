// SPDX-FileCopyrightText: 2023-2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.15
import QtQuick.Layouts 2.15

Item {
    id: root
    required property bool useColumnLayout
    property real trailingExtent: 0
    property alias model: listView.model
    property alias delegate: listView.delegate
    property alias spacing: listView.spacing
    property alias count: listView.count
    property alias add: listView.add
    property alias remove: listView.remove
    property alias move: listView.move
    property alias displaced: listView.displaced
    property alias addDisplaced: listView.addDisplaced
    property alias removeDisplaced: listView.removeDisplaced
    property alias moveDisplaced: listView.moveDisplaced
    ListView {
        Accessible.id: "ListView"
        id: listView
        anchors.fill: parent
        orientation: useColumnLayout ? ListView.Vertical : ListView.Horizontal
        layoutDirection: Qt.LeftToRight
        verticalLayoutDirection: ListView.TopToBottom
        interactive: false
        onCountChanged: Qt.callLater(listView.forceLayout)
        Accessible.role: Accessible.List
    }

    function calculateImplicitWidth(prev, current) {
        // Zero-width delegates are hidden (for example, items moved into the
        // overflow popup) and must not leave an extra spacing slot behind.
        if (current <= 0) {
            return prev
        }
        if (useColumnLayout) {
            return Math.max(prev, current)
        } else {
            if (prev == 0) {
                return current
            }
            return prev + root.spacing + current
        }
    }

    function calculateImplicitHeight(prev, current) {
        // Keep the vertical layout consistent with the horizontal one: hidden
        // delegates contribute neither size nor spacing.
        if (current <= 0) {
            return prev
        }
        if (useColumnLayout) {
            if (prev == 0) {
                return current
            }
            return prev + root.spacing + current
        } else {
            return Math.max(prev, current)
        }
    }

    function indexAt(x, y) {
        return listView.indexAt(x, y)
    }

    implicitWidth: {
        let width = 0
        for (let child of listView.contentItem.visibleChildren) {
            width = calculateImplicitWidth(width, child.implicitWidth)
        }
        if (!useColumnLayout && trailingExtent > 0)
            width = calculateImplicitWidth(width, trailingExtent)
        // TODO: abvoe qt6.8 implicitSize to 0 will make size to 0 default.
        // so make minimum implicitSize to 1, find why and remove below
        return Math.max(width, 1)
    }
    implicitHeight: {
        let height = 0
        for (let child of listView.contentItem.visibleChildren) {
            height = calculateImplicitHeight(height, child.implicitHeight)
        }
        if (useColumnLayout && trailingExtent > 0)
            height = calculateImplicitHeight(height, trailingExtent)
        return Math.max(height, 1)
    }
}

// SPDX-FileCopyrightText: 2024 - 2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick
import QtQuick.Controls
import Qt.labs.qmlmodels
import org.deepin.dtk 1.0
import org.deepin.ds.notification
import org.deepin.ds.notificationcenter

DelegateChooser {
    id: root
    required property NotifyModel notifyModel
    required property Item view

    signal setting(var pos, var params)

    role: "type"

    // Shared navigation helper: focus next item or cycle to header
    function navigateToNextItem(currentIndex) {
        if (currentIndex < view.count - 1) {
            view.currentIndex = currentIndex + 1
            view.positionViewAtIndex(currentIndex + 1, ListView.Contain)
            Qt.callLater(function() {
                let nextItem = view.itemAtIndex(currentIndex + 1)
                if (nextItem && nextItem.enabled) {
                    nextItem.focusedByNavigation = true
                    nextItem.resetFocus()
                    nextItem.forceActiveFocus()
                }
            })
        } else {
            view.gotoHeaderFirst()
        }
    }

    // Shared navigation helper: focus previous item or cycle to header
    function navigateToPrevItem(currentIndex) {
        if (currentIndex > 0) {
            view.currentIndex = currentIndex - 1
            view.positionViewAtIndex(currentIndex - 1, ListView.Contain)
            Qt.callLater(function() {
                let prevItem = view.itemAtIndex(currentIndex - 1)
                if (prevItem && prevItem.enabled) {
                    prevItem.focusedByNavigation = true
                    prevItem.forceActiveFocus()
                }
            })
        } else {
            view.gotoHeaderLast()
        }
    }

    DelegateChoice {
        roleValue: "group"
        GroupNotify {
            Accessible.id: "NotifyViewDelegate_AlertMessage"
            Accessible.role: Accessible.ListItem
            id: groupNotify
            objectName: "group-" + model.appName
            width: NotifyStyle.contentItem.width
            appName: model.appName
            activeFocusOnTab: false
            z: index

            onGotoNextItem: root.navigateToNextItem(index)
            onGotoPrevItem: root.navigateToPrevItem(index)

            onCollapse: function () {
                console.log("collapse group", model.appName)
                let collapseIndex = index
                notifyModel.collapseApp(index)
                root.view.jiggleUpdate()
                root.view.requestFocusOnExpand(collapseIndex)
            }

            onSetting: function (pos) {
                let tmp = mapToItem(root.view, pos)
                root.setting(tmp, {
                                 appName: model.appName,
                                 pinned: model.pinned
                             })
            }
            onRemove: function () {
                console.log("remove group", model.appName)
                notifyModel.removeByApp(model.appName)
            }
        }
    }

    DelegateChoice {
        roleValue: "normal"
        NormalNotify {
            Accessible.id: "NotifyViewDelegate_AlertMessage_2"
            Accessible.role: Accessible.ListItem
            id: normalNotify
            objectName: "normal-" + model.appName
            width: NotifyStyle.contentItem.width
            activeFocusOnTab: false
            z: index

            onGotoNextItem: root.navigateToNextItem(index)
            onGotoPrevItem: root.navigateToPrevItem(index)

            appName: model.appName
            iconName: model.iconName
            date: model.time
            actions: model.actions
            title: model.title
            content: model.content
            strongInteractive: model.strongInteractive
            contentIcon: model.contentIcon
            contentRowCount: model.contentRowCount
            defaultAction: model.defaultAction
            indexInGroup: model.indexInGroup

            // Mouse/other devices right-click for context menu
            // Note: TouchScreen is excluded because its events bypass acceptedButtons check in Qt
            TapHandler {
                acceptedButtons: Qt.RightButton
                acceptedDevices: PointerDevice.AllDevices & ~PointerDevice.TouchScreen
                onPressedChanged: function () {
                    if (pressed) {
                        let pos = point.position
                        setting(pos)
                    }
                }
            }

            // Touchscreen long-press for context menu
            TapHandler {
                acceptedDevices: PointerDevice.TouchScreen
                onLongPressed: {
                    let pos = point.position
                    setting(pos)
                }
            }

            onSetting: function (pos) {
                let tmp = mapToItem(root.view, pos)
                root.setting(tmp, {
                                 appName: model.appName,
                                 pinned: model.pinned
                             })
            }
            onRemove: function () {
                console.log("remove normal", model.id)
                let removeIndex = index
                notifyModel.remove(model.id)
                root.view.nextIndex = Math.min(removeIndex, root.view.count - 1)
            }
            onDismiss: function () {
                console.log("dismiss normal", model.id)
                let dismissIndex = index
                notifyModel.remove(model.id)
                root.view.nextIndex = Math.min(dismissIndex, root.view.count - 1)
            }
            onActionInvoked: function (actionId) {
                console.log("action normal", model.id, actionId)
                notifyModel.invokeAction(model.id, actionId)
            }
        }
    }

    DelegateChoice {
        roleValue: "overlap"
        OverlapNotify {
            Accessible.id: "NotifyViewDelegate_AlertMessage_3"
            Accessible.role: Accessible.Pane
            id: overlapNotify
            objectName: "overlap-" + model.appName
            width: NotifyStyle.contentItem.width
            activeFocusOnTab: false
            z: index

            onGotoNextItem: root.navigateToNextItem(index)
            onGotoPrevItem: root.navigateToPrevItem(index)

            count: model.overlapCount
            appName: model.appName
            iconName: model.iconName
            date: model.time
            actions: model.actions
            title: model.title
            content: model.content
            strongInteractive: model.strongInteractive
            contentIcon: model.contentIcon
            contentRowCount: model.contentRowCount
            enableDismissed: false
            notifyContent.clearButton: AnimationSettingButton {
                Accessible.id: "NotifyViewDelegate_Button"
                Accessible.role: Accessible.Button
                id: clearBtn
                icon.name: "clean-alone"
                text: qsTr("Clean All")
                activeFocusOnTab: false
                focusBorderVisible: activeFocus
                Keys.onTabPressed: function(event) {
                    // Try to focus first action button (skip clear button to avoid loop)
                    if (notifyContent.focusFirstActionOnly()) {
                        event.accepted = true
                        return
                    }
                    // No enabled action buttons, go to next item
                    overlapNotify.gotoNextItem()
                    event.accepted = true
                }
                Keys.onBacktabPressed: function(event) {
                    // Shift+Tab: go back to previous item (clear button is first in tab order)
                    overlapNotify.gotoPrevItem()
                    event.accepted = true
                }
                onClicked: function () {
                    notifyContent.remove()
                }
            }

            // Mouse/other devices right-click for context menu
            // Note: TouchScreen is excluded because its events bypass acceptedButtons check in Qt
            TapHandler {
                acceptedButtons: Qt.RightButton
                acceptedDevices: PointerDevice.AllDevices & ~PointerDevice.TouchScreen
                onPressedChanged: function () {
                    if (pressed) {
                        let pos = point.position
                        setting(pos)
                    }
                }
            }

            // Touchscreen long-press for context menu
            TapHandler {
                acceptedDevices: PointerDevice.TouchScreen
                onLongPressed: {
                    let pos = point.position
                    setting(pos)
                }
            }

            onExpand: function ()
            {
                console.log("expand")
                let expandIndex = model.index
                notifyModel.expandApp(expandIndex)
                root.view.jiggleUpdate()
                root.view.requestFocusOnExpand(expandIndex + 1)
            }
            onSetting: function (pos) {
                let tmp = mapToItem(root.view, pos)
                root.setting(tmp, {
                                 appName: model.appName,
                                 pinned: model.pinned
                             })
            }
            onRemove: function () {
                console.log("remove overlap", model.appName)
                notifyModel.removeByApp(model.appName)
            }
            onActionInvoked: function (actionId) {
                console.log("action overlap", model.id, actionId)
                notifyModel.invokeAction(model.id, actionId)
            }
        }
    }
}

// SPDX-FileCopyrightText: 2023-2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.15
import QtQuick.Controls 2.15

import org.deepin.ds 1.0
import org.deepin.ds.dock 1.0
import org.deepin.ds.dock.taskmanager 1.0
import org.deepin.dtk 1.0 as D

ContainmentItem {
    id: taskmanager
    property bool useColumnLayout: Panel.rootObject.useColumnLayout
    property int dockOrder: 16
    readonly property bool fashionMode: Panel.fashionMode

    Accessible.role: Accessible.Grouping
    Accessible.name: qsTr("Task Manager")

    function calcRemainingSpace(baseSize) {
        const otherCount = Panel.rootObject.dockCenterPartCount - 1;
        const otherOccupied = otherCount > 0 ? otherCount * baseSize * multitaskViewIconRatio : 0;
        return Panel.rootObject.dockEffectiveCenterSpace - otherOccupied;
    }

    property real remainingSpacesForTaskManager: fashionMode
        ? 0
        : calcRemainingSpace(Panel.rootObject.dockItemMaxSize)
    readonly property int appTitleSpacing: Math.max(10, Math.round(Panel.rootObject.dockItemMaxSize * 9 / 14) / 3)
    // Start padding for the app container so that the visual gap
    // (multitask icon right edge → first app icon left edge) = appTitleSpacing.
    // Compensates for the multitask view's box being wider than its icon.
    // 4/5 = 0.8: multitask button width relative to dockItemMaxSize.
    // Derived from the 1:4 spacing ratio (app icon : dock item height = 4:1, so content = 4/5 = 0.8).
    // Matches AppletDockItem.qml implicitWidth/Height ratio.
    readonly property real multitaskViewIconRatio: 0.8
    // 9/14 ≈ 0.64: app icon size relative to dockItemMaxSize (iconSize:dockHeight = 9:14).
    // Defined in main.qml as dockItemIconSize = dockItemMaxSize * 9 / 14.
    // At default dock size (56), icon = 36px; at min (37), icon ≈ 24px; at max (100), icon ≈ 64px.
    readonly property real iconWidthToMaxSizeRatio: 9 / 14
    readonly property real startPadding: Math.max(0, appTitleSpacing - (Panel.rootObject.dockItemMaxSize * (multitaskViewIconRatio - iconWidthToMaxSizeRatio) / 2))

    implicitWidth: {
        // In column layout the width is the cross axis: it is fixed to the dock
        // size, so do not depend on appContainer.implicitWidth (the delegates
        // read this implicitWidth back, which would cause a binding loop).
        if (useColumnLayout)
            return Panel.rootObject.dockSize
        let w = appContainer.implicitWidth + startPadding
        // Fashion mode hugs its content instead of filling the dock, and
        // remainingSpacesForTaskManager is 0 there, so skip the clamping.
        if (fashionMode)
            return w
        return Panel.itemAlignment === Dock.LeftAlignment ? Math.max(remainingSpacesForTaskManager, w) : Math.min(remainingSpacesForTaskManager, w)
    }
    implicitHeight: {
        // In row layout the height is the cross axis: it is fixed to the dock
        // size, so do not depend on appContainer.implicitHeight (the delegates
        // read this implicitHeight back, which would cause a binding loop).
        if (!useColumnLayout)
            return Panel.rootObject.dockSize
        let h = appContainer.implicitHeight + startPadding
        // See implicitWidth: fashion mode sizes to its content.
        if (fashionMode)
            return h
        return Panel.itemAlignment === Dock.LeftAlignment ? Math.max(remainingSpacesForTaskManager, h) : Math.min(remainingSpacesForTaskManager, h)
    }

    onFashionModeChanged: taskmanager.Applet.setFashionMode(fashionMode)
    // Helper function to find the current index of an app by its appId in the visualModel
    function findAppIndex(appId) {
        for (let i = 0; i < visualModel.items.count; i++) {
            const item = visualModel.items.get(i);
            if (item.model.itemId === appId) {
                return item.itemsIndex
            }
        }
        return -1
    }
    
    // Helper function to find the current index by window ID (for windowSplit mode)
    function findAppIndexByWindow(appId, winId) {
        if (!winId) return findAppIndex(appId)
        for (let i = 0; i < visualModel.items.count; i++) {
            const item = visualModel.items.get(i);
            if (item.model.itemId === appId && item.model.windows.length > 0 && item.model.windows[0] === winId) {
                return item.itemsIndex
            }
        }
        return -1
    }

    function blendColorAlpha(fallback) {
        var appearance = DS.applet("org.deepin.ds.dde-appearance")
        if (!appearance || appearance.opacity < 0)
            return fallback
        return appearance.opacity
    }
    property real blendOpacity: blendColorAlpha(D.DTK.themeType === D.ApplicationHelper.DarkType ? 0.25 : 1.0)

    TaskOverflowController {
        id: taskOverflow
        // Window-split title layout has priority. Otherwise keep the dock-sized
        // icons and move excess tasks into overflow.
        enabled: !textCalculator.enabled || textCalculator.totalWidth <= 0
        availableExtent: Math.max(0, taskmanager.calcRemainingSpace(Panel.rootObject.dockItemMaxSize) - taskmanager.startPadding)
        fallbackItemExtent: Math.max(1, Panel.rootObject.dockItemMaxSize * taskmanager.iconWidthToMaxSizeRatio)
        spacing: taskmanager.appTitleSpacing
        overflowSidePadding: taskmanager.appTitleSpacing + 1
        visualModel: visualModel
        dataModel: taskmanager.Applet.dataModel
    }

    TextCalculator {
        id: textCalculator
        enabled: !fashionMode && taskmanager.Applet.windowSplit && (Panel.position == Dock.Bottom || Panel.position == Dock.Top)
        dataModel: taskmanager.Applet.dataModel
        iconSize: Panel.rootObject.dockSize * 9 / 14
        spacing: Math.max(10, Math.round(textCalculator.iconSize) / 3)
        cellSize: textCalculator.iconSize
        itemPadding: Math.round(textCalculator.iconSize / 8)
        remainingSpace: {
            const dockIconSize = Panel.rootObject.dockSize;
            const startPadding = Math.max(0, textCalculator.spacing - (dockIconSize * (multitaskViewIconRatio - iconWidthToMaxSizeRatio) / 2));
            return calcRemainingSpace(dockIconSize) - startPadding;
        }
        font.family: D.DTK.fontManager.t6.family
        font.pixelSize: Math.max(10, Math.min(20, Math.round(textCalculator.iconSize * 0.35)))
    }

    OverflowContainer {
        Accessible.role: Accessible.Pane
        Accessible.id: "AppContainer"
        id: appContainer
        anchors.fill: parent
        anchors.leftMargin: useColumnLayout ? 0 : taskmanager.startPadding
        anchors.topMargin: useColumnLayout ? taskmanager.startPadding : 0
        useColumnLayout: taskmanager.useColumnLayout
        spacing: taskmanager.appTitleSpacing
        trailingExtent: taskOverflow.trailingExtent
        remove: Transition {
            NumberAnimation {
                properties: "scale,opacity"
                from: 1
                to: 0
                duration: 200
            }
        }
        model: DelegateModel {
            id: visualModel
            model: taskmanager.Applet.dataModel
            function sourceIndexAt(visualIndex) {
                // modelIndex() takes a source row, whereas items can be reordered.
                return modelIndex(items.get(visualIndex).model.index)
            }
            // 1:4 the distance between app : dock height; get width/height≈0.8
            property real cellWidth: Panel.rootObject.dockItemMaxSize * 0.8
            delegate: Item {
                id: delegateRoot
                required property int index
                required property bool active
                required property bool attention
                required property string itemId
                required property string name
                required property string title // winTitle
                required property string iconName
                required property string icon // winIconName
                required property string folderType
                required property var applicationFolderContents
                required property var folderPresentation
                required property string menus
                required property list<string> windows
                z: attention ? -1 : 0
                property bool visibility: {
                    let draggedAppId = taskmanager.Applet.desktopIdToAppId(launcherDndDropArea.launcherDndDesktopId)
                    if (itemId !== draggedAppId) {
                        return true 
                    }
                    return windows.length > 0 && launcherDndDropArea.launcherDndWinId !== windows[0]
                }

                readonly property bool overflowActive: taskOverflow.popupCount > 0
                readonly property bool hiddenInOverflow: overflowActive
                    && DelegateModel.itemsIndex >= taskOverflow.visibleItemCount
                visible: !hiddenInOverflow

                readonly property real normalDelegateWidth: useColumnLayout
                    ? taskmanager.implicitWidth
                    : appItem.implicitWidth
                readonly property real normalDelegateHeight: useColumnLayout
                    ? Panel.rootObject.dockItemMaxSize * 9 / 14
                    : taskmanager.implicitHeight

                ListView.onAdd: NumberAnimation {
                    target: delegateRoot
                    properties: "scale,opacity"
                    from: 0
                    to: 1
                    duration: 200
                }

                states: [
                    State {
                        name: "item-visible"
                        when: delegateRoot.visibility
                        PropertyChanges { target: delegateRoot; opacity: 1.0; scale: 1.0; }
                    },
                    State {
                        name: "item-invisible"
                        when: !delegateRoot.visibility
                        PropertyChanges { target: delegateRoot; opacity: 0.0; scale: 0.0; }
                    }
                ]

                Behavior on opacity { NumberAnimation { duration: 200 } }
                Behavior on scale { NumberAnimation { duration: 200 } }

                implicitWidth: hiddenInOverflow? 0 : normalDelegateWidth
                implicitHeight: hiddenInOverflow? 0 : normalDelegateHeight

                property int visualIndex: DelegateModel.itemsIndex
                property var modelIndex: visualModel.modelIndex(index)

                Rectangle {
                    // kept for debug purpose
                    // border.color: "red"
                    // border.width: 1
                    id: appItemRect
                    color: "transparent"
                    parent: appContainer
                    x: delegateRoot.x
                    y: delegateRoot.y
                    width: delegateRoot.width
                    height: delegateRoot.height
                    readonly property bool hiddenByOverflow: delegateRoot.hiddenInOverflow
                    scale: delegateRoot.scale * (hiddenByOverflow ? 0.8 : 1.0)
                    opacity: positionAnimationEnabled && !hiddenByOverflow ? 1 : 0
                    visible: opacity > 0.001
                    property bool positionAnimationEnabled: false

                    onHiddenByOverflowChanged: {
                        positionAnimationEnabled = false
                        if (!hiddenByOverflow)
                            Qt.callLater(preparePosition)
                    }

                    function preparePosition() {
                        if (hiddenByOverflow || !delegateRoot.ListView.view)
                            return
                        // Lay out and center the returning icon before revealing it.
                        delegateRoot.ListView.view.forceLayout()
                        appItem.syncIconPosition()
                        positionAnimationEnabled = true
                    }

                    Behavior on x {
                        enabled: appItemRect.positionAnimationEnabled
                        NumberAnimation {
                            duration: 200
                            easing.type: Easing.OutCubic
                        }
                    }
                    Behavior on y {
                        enabled: appItemRect.positionAnimationEnabled
                        NumberAnimation {
                            duration: 200
                            easing.type: Easing.OutCubic
                        }
                    }

                    Component.onCompleted: Qt.callLater(preparePosition)

                    AppItem {
                        Accessible.role: Accessible.ListItem
                        Accessible.id: "AppItem"
                        id: appItem
                        anchors.fill: parent // This is mandatory for draggable item center in drop area

                        displayMode: Panel.indicatorStyle
                        colorTheme: Panel.colorTheme
                        active: delegateRoot.active
                        attention: delegateRoot.attention
                        itemId: delegateRoot.itemId
                        name: delegateRoot.name
                        iconName: delegateRoot.iconName
                        folderType: delegateRoot.folderType
                        applicationFolderContents: delegateRoot.applicationFolderContents
                        folderPresentation: delegateRoot.folderPresentation
                        menus: delegateRoot.menus
                        windows: delegateRoot.windows
                        visualIndex: delegateRoot.visualIndex
                        modelIndex: delegateRoot.modelIndex
                        blendOpacity: taskmanager.blendOpacity
                        title: delegateRoot.title
                        enableTitle: textCalculator.enabled
                        updateIconGeometry: !delegateRoot.hiddenInOverflow
                        ListView.delayRemove: Drag.active
                        Component.onCompleted: {
                            dropFilesOnItem.connect(taskmanager.Applet.dropFilesOnItem)
                        }
                        onDragFinished: function() {
                            launcherDndDropArea.resetDndState()
                        }
                    }
                }
            }
        }

        TaskOverflowButton {
            id: overflowButton
            taskManagerItem: taskmanager
            overflow: taskOverflow
            onDragFinished: function(dropAction, itemId, canUndock) {
                launcherDndDropArea.finishDrag(dropAction, itemId, canUndock)
            }
        }

        DropArea {
            id: launcherDndDropArea
            anchors.fill: parent
            z: 3
            keys: ["text/x-dde-dock-dnd-appid", "text/x-dde-dock-dnd-folder"]
            property string launcherDndDesktopId: ""
            property string launcherDndDragSource: ""
            property string launcherDndWinId: ""
            property bool launcherDndDocked: false
            property var pendingOverflowDrop: null

            function overflowTargetIndexAt(x, y) {
                // Include gaps and the trailing shortcuts in the drop target.
                // A full taskbar makes room by pushing its last app into overflow.
                const axisPosition = taskmanager.useColumnLayout ? y : x
                const index = Math.floor((axisPosition + taskOverflow.spacing / 2)
                    / (taskOverflow.fallbackItemExtent + taskOverflow.spacing))
                return Math.max(0, Math.min(index, taskOverflow.visibleItemCount - 1))
            }

            function saveOrder() {
                let appIds = []
                for (let i = 0; i < visualModel.items.count; i++) {
                    appIds.push(visualModel.items.get(i).model.itemId)
                }
                taskmanager.Applet.saveDockElementsOrder(appIds)
            }

            function moveApp(appId, winId, targetIndex) {
                const currentIndex = taskmanager.Applet.windowSplit
                    ? taskmanager.findAppIndexByWindow(appId, winId)
                    : taskmanager.findAppIndex(appId)
                if (currentIndex < 0 || targetIndex < 0) return false
                if (currentIndex !== targetIndex) {
                    if (taskmanager.Applet.windowSplit)
                        taskmanager.Applet.moveItem(currentIndex, targetIndex)
                    else
                        visualModel.items.move(currentIndex, targetIndex)
                    taskOverflow.scheduleSync()
                }
                return true
            }

            function finishDrag(dropAction, itemId, canUndock) {
                const pending = pendingOverflowDrop
                pendingOverflowDrop = null
                const shouldUndock = taskOverflow.finishDrag(dropAction)
                resetDndState()
                // Both moves and unpinning can destroy the source. Commit them
                // only after QDrag and the initiating MouseArea event return.
                Qt.callLater(function() {
                    if (pending && dropAction === Qt.MoveAction) {
                        const targetIndex = Math.min(pending.targetIndex, taskOverflow.visibleItemCount - 1)
                        if (moveApp(pending.appId, pending.winId, targetIndex))
                            saveOrder()
                    } else if (canUndock && shouldUndock) {
                        taskmanager.Applet.requestUndockByDesktopId(itemId)
                    }
                })
            }

            function resetDndState() {
                launcherDndDesktopId = ""
                launcherDndDragSource = ""
                launcherDndWinId = ""
                launcherDndDocked = false
            }

            function isOverflowButtonIndex(targetIndex) {
                return taskOverflow.popupCount > 0
                    && (targetIndex < 0 || targetIndex >= taskOverflow.visibleItemCount)
            }

            function targetIndexAt(x, y) {
                return appContainer.indexAt(x, y)
            }

            function isInternalDrag() {
                return launcherDndDragSource === "taskbar"
                    || launcherDndDragSource === "overflow-popup"
            }

            function requestDockIfNeeded() {
                if (isInternalDrag() || launcherDndDocked) {
                    return true
                }

                if (taskmanager.Applet.requestDockByDesktopId(launcherDndDesktopId) === false) {
                    resetDndState()
                    return false
                }

                launcherDndDocked = true
                return true
            }

            onEntered: function(drag) {
                let desktopId = drag.getDataAsString("text/x-dde-dock-dnd-folder") || drag.getDataAsString("text/x-dde-dock-dnd-appid")
                if (!desktopId) {
                    drag.accepted = false
                    resetDndState()
                    return
                }
                launcherDndDragSource = drag.getDataAsString("text/x-dde-dock-dnd-source")
                launcherDndWinId = drag.getDataAsString("text/x-dde-dock-dnd-winid")
                launcherDndDesktopId = desktopId
                if (launcherDndDragSource === "overflow-popup") {
                    pendingOverflowDrop = null
                    drag.acceptProposedAction()
                    return
                }
                let targetIndex = targetIndexAt(drag.x, drag.y)
                if (!isOverflowButtonIndex(targetIndex) && !requestDockIfNeeded()) {
                    drag.accepted = false
                    return
                }
                if (!isOverflowButtonIndex(targetIndex)) {
                    drag.acceptProposedAction()
                }
            }

            onPositionChanged: function(drag) {
                if (launcherDndDesktopId === "") return
                if (launcherDndDragSource === "overflow-popup") return
                let targetIndex = targetIndexAt(drag.x, drag.y)
                if (isOverflowButtonIndex(targetIndex) || !requestDockIfNeeded()) return
                drag.acceptProposedAction()
                let appId = taskmanager.Applet.desktopIdToAppId(launcherDndDesktopId)
                let currentIndex = taskmanager.Applet.windowSplit ? taskmanager.findAppIndexByWindow(appId, launcherDndWinId) : taskmanager.findAppIndex(appId)
                if (currentIndex !== -1 && targetIndex !== -1 && currentIndex !== targetIndex) {
                    if (taskmanager.Applet.windowSplit) {
                        taskmanager.Applet.moveItem(currentIndex, targetIndex)
                    } else {
                        visualModel.items.move(currentIndex, targetIndex)
                        taskOverflow.scheduleSync()
                    }
                }
            }

            onDropped: function(drop) {
                if (launcherDndDesktopId === "") return
                if (launcherDndDragSource === "overflow-popup") {
                    pendingOverflowDrop = {
                        appId: taskmanager.Applet.desktopIdToAppId(launcherDndDesktopId),
                        winId: launcherDndWinId,
                        targetIndex: overflowTargetIndexAt(drop.x, drop.y)
                    }
                    drop.accept(Qt.MoveAction)
                    resetDndState()
                    return
                }
                Panel.contextDragging = false
                let targetIndex = targetIndexAt(drop.x, drop.y)
                if (isOverflowButtonIndex(targetIndex)) {
                    resetDndState()
                    return
                }
                if (!requestDockIfNeeded()) return
                let appId = taskmanager.Applet.desktopIdToAppId(launcherDndDesktopId)
                let currentIndex = taskmanager.Applet.windowSplit ? taskmanager.findAppIndexByWindow(appId, launcherDndWinId) : taskmanager.findAppIndex(appId)
                if (currentIndex !== -1 && targetIndex !== -1 && currentIndex !== targetIndex) {
                    if (taskmanager.Applet.windowSplit) {
                        taskmanager.Applet.moveItem(currentIndex, targetIndex)
                    } else {
                        visualModel.items.move(currentIndex, targetIndex)
                        taskOverflow.scheduleSync()
                    }
                }
                saveOrder()
                if (drop.formats.indexOf("text/x-dde-dock-dnd-folder") !== -1) {
                    drop.accept(Qt.CopyAction)
                } else if (isInternalDrag()) {
                    drop.accept(Qt.MoveAction)
                } else {
                    drop.acceptProposedAction()
                }
                resetDndState()
            }

            onExited: function() {
                if (launcherDndDesktopId !== "" && !isInternalDrag() && launcherDndDocked) {
                    taskmanager.Applet.requestUndockByDesktopId(launcherDndDesktopId)
                }
                resetDndState()
            }
        }
    }

    Component.onCompleted: {
        taskmanager.Applet.setFashionMode(fashionMode)
        taskOverflow.scheduleSync()
    }
}

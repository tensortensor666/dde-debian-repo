// SPDX-FileCopyrightText: 2023 - 2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.15
import QtQuick.Controls 2.15

import org.deepin.ds 1.0
import org.deepin.ds.dock 1.0
import org.deepin.dtk 1.0 as D
import Qt.labs.platform 1.1 as LP

Item {
    id: root
    required property int displayMode
    required property int colorTheme
    required property bool active
    required property bool attention
    required property string itemId
    required property string name
    required property string iconName
    required property string menus
    required property list<string> windows
    required property int visualIndex
    required property var modelIndex
    required property string title

    property var applicationFolderContents: []
    property string folderType: ""
    property var folderPresentation: null
    readonly property bool isFolder: folderType !== ""
    property real blendOpacity: 1.0
    property bool dragEnabled: true
    property string dragSource: "taskbar"
    property bool restorePositionAfterDrag: false
    property real dragStartX: 0
    property real dragStartY: 0
    property bool dragFinishedForPress: false

    signal dropFilesOnItem(itemId: string, files: list<string>)
    signal dragFinished(int dropAction)

    // Binding Drag.active to mouseArea.drag.active would make Drag.active read
    // back the very property it drives (see visible/fixPosition below),
    // causing a QML binding loop. Set it imperatively from the MouseArea instead.
    Drag.active: false
    Drag.source: root
    Drag.hotSpot.x: icon.width / 2
    Drag.hotSpot.y: icon.height / 2
    Drag.dragType: Drag.Automatic

    Accessible.role: Accessible.Button
    Accessible.name: root.name
    Accessible.description: root.attention ? qsTr("Demands attention") : (root.active ? qsTr("Active") : "")
    
    Drag.supportedActions: Qt.CopyAction | Qt.MoveAction
    Drag.mimeData: root.folderPresentation
        ? { "text/x-dde-dock-dnd-folder": itemId, "text/x-dde-dock-dnd-source": dragSource }
        : { "text/x-dde-dock-dnd-appid": itemId, "text/x-dde-dock-dnd-source": dragSource, "text/x-dde-dock-dnd-winid": windows.length > 0 ? windows[0] : ""}
    Drag.onDragFinished: function(dropAction) {
        // MouseArea is still processing the initiating move while the native
        // drag returns. Keep its target alive until that event has finished.
        Qt.callLater(function() {
            if (!root)
                return
            root.dragFinishedForPress = true
            if (root.restorePositionAfterDrag) {
                root.x = root.dragStartX
                root.y = root.dragStartY
            }
        })
        Panel.contextDragging = false
        root.dragFinished(dropAction)
    }

    property bool useColumnLayout: Panel.rootObject.useColumnLayout
    property real iconSize: Panel.rootObject.dockItemMaxSize * 9 / 14
    property bool enableTitle: false
    property bool titleActive: enableTitle && titleLoader.active
    property bool preservePanelPopupOnContextMenu: false
    property bool updateIconGeometry: true
    property Item previewAnchor: icon
    // Folder content replaces the overflow popup, so anchor it to the dock.
    property Item folderAnchor: root
    property var iconGlobalPoint: {
        var a = icon
        var x = 0, y = 0
        while(a.parent) {
            x += a.x
            y += a.y
            a = a.parent
        }

        return Qt.point(x, y)
    }

    implicitWidth: appItem.implicitWidth

    function syncIconPosition() {
        fixPositionTimer.stop()
        icon.fixPosition()
    }

    // Monitor Panel position changes to update icon geometry
    Connections {
        target: Panel.rootObject
        function onXChanged() {
            updateWindowIconGeometryTimer.start()
        }
        function onYChanged() {
            updateWindowIconGeometryTimer.start()
        }
    }

    AppItemPalette {
        Accessible.role: Accessible.Pane
        Accessible.id: "ItemPalette"
        id: itemPalette
        displayMode: root.displayMode
        colorTheme: root.colorTheme
        active: root.active
        backgroundColor: D.DTK.palette.highlight
    }

    Control {
        id: appItem
        width: root.useColumnLayout ? parent.width : hoverBackground.width
        height: root.useColumnLayout ? hoverBackground.height : parent.height
        anchors.centerIn: parent
        implicitWidth: root.titleActive ? (root.iconSize + hoverBackground.horizontalSpacing + titleLoader.width) : iconContainer.width
        visible: !root.Drag.active // When in dragging, hide app item
        background: AppItemBackground {
            Accessible.ignored: true
            id: hoverBackground

            readonly property int verticalSpacing: Math.round(root.iconSize / 8) + 1
            readonly property int horizontalSpacing: Math.round(root.iconSize / 8)
            readonly property int nonSplitHeight: root.iconSize + verticalSpacing * 2
            readonly property int splitWidth: Math.round(root.iconSize + titleLoader.width + horizontalSpacing * 3)
            readonly property int nonSplitWidth: Math.round(root.iconSize + horizontalSpacing * 2)

            enabled: false

            width: root.titleActive ? splitWidth : nonSplitWidth
            height: nonSplitHeight
            radius: height / 5
            anchors.centerIn: parent
            isActive: root.active
            windowCount: root.windows.length
            displayMode: root.displayMode
            D.ColorSelector.hovered: hoverHandler.hovered
            D.ColorSelector.pressed: mouseArea.pressed
        }
        Item {
            id: iconContainer
            width: root.iconSize 
            height: parent.height
            anchors.verticalCenter: parent.verticalCenter
            states: [
                State {
                    name: "titleActive"
                    when: root.titleActive

                    AnchorChanges {
                        target: iconContainer
                        anchors.left: parent.left
                        anchors.horizontalCenter: undefined
                    }
                    PropertyChanges {
                        target: iconContainer
                        anchors.leftMargin: hoverBackground.horizontalSpacing
                    }
                },
                State {
                    name: "nonTitleActive"
                    when: !root.titleActive

                    AnchorChanges {
                        target: iconContainer
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.left: undefined
                    }
                }
            ]

            Connections {
                function onDisplayModeChanged() {
                    windowIndicator.updateIndicatorAnchors()
                }
                target: root
            }

            Connections {
                function onPositionChanged() {
                    windowIndicator.updateIndicatorAnchors()
                    updateWindowIconGeometryTimer.start()
                }
                target: Panel
            }

            D.DciIcon {
                id: icon
                name: root.isFolder ? "" : root.iconName
                height: iconSize
                width: iconSize
                sourceSize: Qt.size(iconSize, iconSize)
                anchors.centerIn: parent
                retainWhileLoading: true
                smooth: animationRoot.active

                Loader {
                    anchors.centerIn: parent
                    width: parent.width - 2
                    height: parent.height - 2
                    active: root.isFolder
                    sourceComponent: FolderIcon {
                        contents: root.applicationFolderContents
                        presentation: root.folderPresentation
                    }
                }

                function mapToScene(px, py) {
                    return parent.mapToItem(Window.window.contentItem, Qt.point(px, py))
                }

                function mapFromScene(px, py) {
                    return parent.mapFromItem(Window.window.contentItem, Qt.point(px, py))
                }

                function fixPosition() {
                    if (root.Drag.active || !parent || launchAnimation.running) {
                        return
                    }
                    anchors.centerIn = undefined
                    var targetX = (parent.width - width) / 2
                    var targetY = (parent.height - height) / 2

                    var scenePos = mapToScene(targetX, targetY)
                    
                    var physicalX = Math.round(scenePos.x * Panel.devicePixelRatio)
                    var physicalY = Math.round(scenePos.y * Panel.devicePixelRatio)

                    var localPos = mapFromScene(physicalX / Panel.devicePixelRatio, physicalY / Panel.devicePixelRatio)
                    
                    x = localPos.x
                    y = localPos.y
                }

                Timer {
                    id: fixPositionTimer
                    interval: 100
                    repeat: false
                    running: false
                    onTriggered: {
                        icon.fixPosition()
                    }
                }

                Connections {
                    target: root
                    function onIconGlobalPointChanged() {
                        fixPositionTimer.start()
                    }
                }
                LaunchAnimation {
                    Accessible.id: "AppItem_Pane_2"
                    id: launchAnimation
                    launchSpace: {
                        switch (Panel.position) {
                        case Dock.Top:
                        case Dock.Bottom:
                            return hoverBackground.verticalSpacing
                        case Dock.Left:
                        case Dock.Right:
                            return hoverBackground.horizontalSpacing
                        }
                    }

                    direction: {
                        switch (Panel.position) {
                        case Dock.Top:
                            return LaunchAnimation.Direction.Down
                        case Dock.Bottom:
                            return LaunchAnimation.Direction.Up
                        case Dock.Left:
                            return LaunchAnimation.Direction.Right
                        case Dock.Right:
                            return LaunchAnimation.Direction.Left
                        }
                    }
                    target: icon
                    loops: 1
                    running: false
                }
            }
        }

        WindowIndicator {
            Accessible.role: Accessible.Indicator
            Accessible.id: "WindowIndicator"
            id: windowIndicator
            dotWidth: root.useColumnLayout  ? Math.max(iconSize / 16, 2) : Math.max(iconSize / 3, 2)
            dotHeight: root.useColumnLayout ? Math.max(iconSize / 3, 2) : Math.max(iconSize / 16, 2)
            windows: root.windows
            displayMode: root.displayMode
            useColumnLayout: root.useColumnLayout
            palette: itemPalette
            visible: (root.displayMode === Dock.Efficient && root.windows.length > 1) || (root.displayMode === Dock.Fashion && root.windows.length > 0)

            function updateIndicatorAnchors() {
                windowIndicator.anchors.top = undefined
                windowIndicator.anchors.topMargin = 0
                windowIndicator.anchors.bottom = undefined
                windowIndicator.anchors.bottomMargin = 0
                windowIndicator.anchors.left = undefined
                windowIndicator.anchors.leftMargin = 0
                windowIndicator.anchors.right = undefined
                windowIndicator.anchors.rightMargin = 0
                windowIndicator.anchors.horizontalCenter = undefined
                windowIndicator.anchors.verticalCenter = undefined

                const anchorTarget = root.displayMode === Dock.Efficient ? appItem : hoverBackground

                switch(Panel.position) {
                case Dock.Top: {
                    windowIndicator.anchors.horizontalCenter = iconContainer.horizontalCenter
                    windowIndicator.anchors.top = anchorTarget.top
                    windowIndicator.anchors.topMargin = 1
                    return
                }
                case Dock.Bottom: {
                    windowIndicator.anchors.horizontalCenter = iconContainer.horizontalCenter
                    windowIndicator.anchors.bottom = anchorTarget.bottom
                    windowIndicator.anchors.bottomMargin = 1
                    return
                }
                case Dock.Left: {
                    windowIndicator.anchors.verticalCenter = parent.verticalCenter
                    windowIndicator.anchors.left = anchorTarget.left
                    windowIndicator.anchors.leftMargin = 1
                    return
                }
                case Dock.Right:{
                    windowIndicator.anchors.verticalCenter = parent.verticalCenter
                    windowIndicator.anchors.right = anchorTarget.right
                    windowIndicator.anchors.rightMargin = 1
                    return
                }
                }
            }

            Component.onCompleted: {
                windowIndicator.updateIndicatorAnchors()
            }
        }

        AppItemTitle {
            Accessible.role: Accessible.StaticText
            Accessible.id: "TitleLoader"
            id: titleLoader
            anchors.left: iconContainer.right
            anchors.leftMargin: Math.round(root.iconSize / 8)
            anchors.verticalCenter: parent.verticalCenter
            enabled: root.enableTitle && root.windows.length > 0
            text: root.title
            textColor: {
                if (root.displayMode === Dock.Efficient && root.active) {
                    return "#000000"
                }
                return D.DTK.themeType === D.ApplicationHelper.DarkType ? "#FFFFFF" : "#000000"
            }
        }

        Loader {
            id: animationRoot
            anchors.fill: parent
            z: -1
            active: root.attention && !Panel.rootObject.isDragging && TaskManager.showAttentionAnimation 
            onActiveChanged: {
                if (!active) {
                    Qt.callLater(function() {
                        icon.scale = 1.0
                    })
                }
            }
            sourceComponent: Repeater {
                model: 5
                Rectangle {
                    id: rect
                    required property int index
                    property var originSize: iconSize

                    width: originSize * (index - 1)
                    height: width
                    radius: width / 2
                    color: Qt.rgba(1, 1, 1, 0.1)

                    anchors.centerIn: parent
                    opacity: Math.min(3 - width / originSize, root.blendOpacity)

                    SequentialAnimation {
                        running: true
                        loops: Animation.Infinite

                        // 弹出
                        ParallelAnimation {
                            NumberAnimation { target: rect; property: "width"; from: Math.max(originSize * (index - 1), 0); to: originSize * (index); duration: 1200 }
                            ColorAnimation { target: rect; property: "color"; from: Qt.rgba(1, 1, 1, 0.4); to: Qt.rgba(1, 1, 1, 0.1); duration: 1200 }
                            NumberAnimation { target: icon; property: "scale"; from: 1.0; to: 1.15; duration: 1200; easing.type: Easing.OutElastic; easing.amplitude: 1; easing.period: 0.2 }
                        }

                        // 收缩
                        ParallelAnimation {
                            NumberAnimation { target: rect; property: "width"; from: originSize * (index); to: originSize * (index + 1); duration: 1200 }
                            ColorAnimation { target: rect; property: "color"; from: Qt.rgba(1, 1, 1, 0.4); to: Qt.rgba(1, 1, 1, 0.1); duration: 1200 }
                            NumberAnimation { target: icon; property: "scale"; from: 1.15; to: 1.0; duration: 1200; easing.type: Easing.OutElastic; easing.amplitude: 1; easing.period: 0.2 }
                        }

                        // 停顿
                        ParallelAnimation {
                            NumberAnimation { target: rect; property: "width"; from: originSize * (index + 1); to: originSize * (index + 2); duration: 1200 }
                            ColorAnimation { target: rect; property: "color"; from: Qt.rgba(1, 1, 1, 0.4); to: Qt.rgba(1, 1, 1, 0.1); duration: 1200 }
                        }
                    }

                    // TODO Remove it because of consuming performance.
                    // D.BoxShadow {
                    //     visible: rect.visible
                    //     anchors.fill: rect
                    //     z: -2
                    //     shadowBlur: 20
                    //     shadowColor : Qt.rgba(0, 0, 0, 0.05)
                    //     shadowOffsetX : 0
                    //     shadowOffsetY : 0
                    //     cornerRadius: rect.radius
                    //     hollow: true
                    // }
                }
            }
        }

        HoverHandler {
            id: hoverHandler
            onHoveredChanged: function () {
                if (hovered) {
                    root.onEntered()
                } else {
                    root.onExited()
                }
            }
        }
    }

    function openFolder() {
        toolTip.close()
        closeItemPreview()
        if (folderUi.item)
            folderUi.item.popup.openAt(folderAnchor.mapToItem(null, folderAnchor.width / 2, folderAnchor.height / 2))
    }

    // One source-neutral popup instance handles launcher folders and provider
    // content. The provider presentation selects its own page inside the same
    // popup lifecycle and positioning template.
    Loader {
        id: folderUi
        active: root.isFolder
        sourceComponent: Item {
            property alias popup: folderPopup
            property alias contextMenu: folderContextMenu
            FolderContextMenu {
                id: folderContextMenu
                registry: TaskManager
                onOpenRequested: root.openFolder()
                onUndockRequested: TaskManager.requestUndockByDesktopId(root.itemId)
            }
            FolderPopup {
                id: folderPopup
                positionerAnchor: root.folderAnchor
                folderName: root.name
                contents: root.applicationFolderContents
                presentation: root.folderPresentation
                interactionActive: applicationMenu.busy
                onActivated: function(entry) {
                    close()
                    TaskManager.launchFolderApplication(entry.id)
                }
                onContextMenuRequested: function(entry) {
                    applicationMenu.openFor(entry, TaskManager.folderApplicationBackend())
                }
            }
            FolderApplicationMenu {
                id: applicationMenu
                onLaunchRequested: function(id) {
                    folderPopup.close()
                    TaskManager.launchFolderApplication(id)
                }
            }
        }
    }

    Loader {
        id: contextMenuLoader
        active: false
        property bool trashEmpty: true
        sourceComponent: LP.Menu {
            id: contextMenu
            Instantiator {
                id: menuItemInstantiator
                model: JSON.parse(menus)
                delegate: LP.MenuItem {
                    text: modelData.name
                    enabled: (root.itemId === "dde-trash" && modelData.id === "clean-trash")
                            ? !contextMenuLoader.trashEmpty
                            : true
                    onTriggered: {
                        TaskManager.requestNewInstance(root.modelIndex, modelData.id);
                    }
                }
                onObjectAdded: (index, object) => contextMenu.insertItem(index, object)
                onObjectRemoved: (index, object) => contextMenu.removeItem(object)
            }
        }
    }

    Timer {
        id: updateWindowIconGeometryTimer
        interval: 500
        running: false
        repeat: false
        onTriggered: {
            if (!root.updateIconGeometry)
                return
            const point = icon.mapToItem(null, 0, 0)
            icon.DockPositioner.bounding = Qt.rect(point.x, point.y, 0, 0)
            icon.DockPositioner.updatePosition()
            const pos = Qt.point(icon.DockPositioner.x, icon.DockPositioner.y)
            taskmanager.Applet.requestUpdateWindowIconGeometry(root.modelIndex, Qt.rect(pos.x, pos.y,
                icon.width, icon.height), Panel.rootObject)
        }
    }

    Timer {
        id: previewTimer
        interval: 500
        running: false
        repeat: false
        property int xOffset: 0
        property int yOffset: 0
        onTriggered: {
            xOffset = root.previewAnchor.DockPanelPositioner.x
            yOffset = root.previewAnchor.DockPanelPositioner.y
            if (root.windows.length != 0 || Qt.platform.pluginName === "wayland") {
                // 使用基于 modelIndex 的预览API，确保精确匹配
                taskmanager.Applet.requestPreview(root.modelIndex, Panel.rootObject, xOffset, yOffset, Panel.position);
            }
        }
    }


    function onEntered() {
        if (windows.length === 0) {
            toolTipShowTimer.start()
            return
        }

        const point = root.previewAnchor.mapToItem(null, root.previewAnchor.width / 2, root.previewAnchor.height / 2)
        root.previewAnchor.DockPanelPositioner.bounding = Qt.rect(point.x, point.y, 0, 0)
        root.previewAnchor.DockPanelPositioner.updatePosition()
        previewTimer.start()
    }

    function onExited() {
        if (toolTipShowTimer.running) {
            toolTipShowTimer.stop()
        }

        if (previewTimer.running) {
            previewTimer.stop()
        }

        if (windows.length === 0) {
            toolTip.close()
            return
        }
        closeItemPreview()
    }

    function closeItemPreview() {
        if (previewTimer.running) {
            previewTimer.stop()
        } else {
            taskmanager.Applet.hideItemPreview()
        }
    }

    function requestAppItemMenu() {
        if (!root.preservePanelPopupOnContextMenu) {
            Panel.requestClosePopup()
        }
        if (root.isFolder) {
            if (folderUi.item) folderUi.item.contextMenu.openFor(root.folderType, root.itemId, root.name)
            return
        }
        contextMenuLoader.trashEmpty = TaskManager.isTrashEmpty()
        contextMenuLoader.active = true
        MenuHelper.openMenu(contextMenuLoader.item)
    }

    MouseArea {
        Accessible.id: "AppItem_Pane_6"
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: false
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        preventStealing: root.dragEnabled
        drag.target: root.dragEnabled && !root.dragFinishedForPress ? root : null
        drag.onActiveChanged: {
            // Automatic drag enters the native event loop synchronously. Protect
            // the popup from focus loss before starting it, not after it returns.
            if (drag.active && folderUi.item) folderUi.item.popup.close()
            Panel.contextDragging = drag.active
            root.Drag.active = drag.active
        }

        // 记录是否是触摸长按导致的，防止在 onClicked 中重复处理
        property bool isTouchLongPressed: false

        TapHandler {
            acceptedDevices: PointerDevice.TouchScreen
            gesturePolicy: TapHandler.DragThreshold
            onLongPressed: {
                mouseArea.isTouchLongPressed = true
                requestAppItemMenu()
            }
        }
        onPressed: function (mouse) {
            isTouchLongPressed = false
            root.dragFinishedForPress = false
            if (root.dragEnabled && mouse.button === Qt.LeftButton) {
                root.dragStartX = root.x
                root.dragStartY = root.y
                appItem.grabToImage(function(result) {
                    root.Drag.imageSource = result.url;
                })
            }
            toolTip.close()
            closeItemPreview()
        }

        onClicked: function (mouse) {
            if (isTouchLongPressed) {
                isTouchLongPressed = false
                return
            }

            let index = root.modelIndex;
            if (mouse.button === Qt.RightButton) {
                requestAppItemMenu()
            } else {
                if (root.isFolder) {
                    root.openFolder()
                    return
                }
                if (root.windows.length === 0) {
                    launchAnimation.start();
                    TaskManager.requestNewInstance(index, "");
                    return;
                }
                TaskManager.requestActivate(index);
            }
        }

        PanelToolTip {
            Accessible.role: Accessible.ToolTip
            Accessible.id: "ToolTip"
            id: toolTip
            toolTipX: icon.DockPanelPositioner.x
            toolTipY: icon.DockPanelPositioner.y
        }

        PanelToolTip {
            Accessible.role: Accessible.ToolTip
            Accessible.id: "MoveToTrash"
            id: dragToolTip
            text: qsTr("Move to Trash")
            toolTipX: icon.DockPanelPositioner.x
            toolTipY: icon.DockPanelPositioner.y
            visible: false
        }

        Timer {
            id: toolTipShowTimer
            interval: 50
            onTriggered: {
                toolTip.text = root.itemId === "dde-trash" ? root.name + "-" + taskmanager.Applet.getTrashTipText() : root.name
                const point = icon.mapToItem(null, icon.width / 2, icon.height / 2)
                icon.DockPanelPositioner.bounding = Qt.rect(point.x, point.y,
                                                            toolTip.width, toolTip.height)
                icon.DockPanelPositioner.updatePosition()
                toolTip.open()
            }
        }
    }

    Timer {
        id: dragToolTipCloseTimer
        interval: 100
        onTriggered: {
            dragToolTip.close()
        }
    }

    DropArea {
        anchors.fill: parent
        keys: ["dfm_app_type_for_drag"]

        onEntered: function (drag) {
            if (root.itemId === "dde-trash") {
                dragToolTipCloseTimer.stop()
                if (!dragToolTip.toolTipVisible) {
                    const point = icon.mapToItem(null, icon.width / 2, icon.height / 2)
                    icon.DockPanelPositioner.bounding = Qt.rect(point.x, point.y,
                                                                dragToolTip.width, dragToolTip.height)
                    icon.DockPanelPositioner.updatePosition()
                    dragToolTip.open()
                }
            }
        }

        onExited: function (drag) {
            if (root.itemId === "dde-trash") {
                dragToolTipCloseTimer.restart()
            }
        }

        onDropped: function (drop){
            dragToolTipCloseTimer.stop()
            dragToolTip.close()
            root.dropFilesOnItem(root.itemId, drop.urls)
        }
    }

    onWindowsChanged: {
        updateWindowIconGeometryTimer.start()
        // Close tooltip when window appears
        if (windows.length > 0 && toolTip.toolTipVisible) {
            toolTip.close()
        }
    }

    onIconGlobalPointChanged: {
        updateWindowIconGeometryTimer.start()
    }

    onUpdateIconGeometryChanged: updateWindowIconGeometryTimer.start()

    // The recent shortcut can change apps while the pointer stays over it.
    onItemIdChanged: {
        if (hoverHandler.hovered) {
            onExited()
            onEntered()
        }
    }

    onVisibleChanged: {
        if (!visible) {
            toolTipShowTimer.stop()
            toolTip.close()
            if (hoverHandler.hovered || previewTimer.running)
                closeItemPreview()
        }
    }
}

// SPDX-FileCopyrightText: 2026 UnionTech Software Technology Co., Ltd.
// SPDX-License-Identifier: GPL-3.0-or-later
import QtQuick
import QtQuick.Controls
import org.deepin.ds 1.0
import org.deepin.ds.dock 1.0
import org.deepin.dtk 1.0 as D

// Source-neutral container: files and applications provide data and callbacks,
// never a second implementation of the popup's sizing, layout or lifecycle.
PanelPopup {
    id: root
    property string folderName
    property var contents: []
    property var presentation: null
    property point anchorPoint: Qt.point(0, 0)
    property Item positionerAnchor: root
    property bool interactionActive: false
    signal activated(var entry)
    signal contextMenuRequested(var entry)

    readonly property bool hasProviderContent: presentation !== null && presentation !== undefined
    readonly property int itemCount: contents.length
    readonly property int columns: itemCount < 4 ? Math.max(1, itemCount) : (itemCount <= 8 ? 4 : 5)
    readonly property int rows: Math.max(1, Math.ceil(itemCount / columns))
    readonly property real itemWidth: 70
    readonly property real itemHeight: 86
    readonly property real hoverWidth: 90
    readonly property real hoverHeight: 98
    readonly property real columnSpacing: 10
    readonly property real rowSpacing: 18
    readonly property real cellWidth: hoverWidth + columnSpacing
    readonly property real cellHeight: hoverHeight + rowSpacing
    readonly property var screen: Panel.rootObject.screen
    // desktopAvailableWidth/Height describe the virtual desktop, not the
    // current monitor. Use its work area, including offsets from other panels.
    readonly property rect workArea: DockPanelPositioner.availableGeometry
    readonly property real screenWidth: workArea.width > 0 ? workArea.width : (screen ? screen.width : 1920)
    readonly property real screenHeight: workArea.height > 0 ? workArea.height : (screen ? screen.height : 1080)
    readonly property real screenX: workArea.width > 0 ? workArea.x : (screen ? screen.virtualX : 0)
    readonly property real screenY: workArea.height > 0 ? workArea.y : (screen ? screen.virtualY : 0)
    readonly property bool verticalDock: Panel.position === Dock.Left || Panel.position === Dock.Right
    // Width follows the actual column count so a sparse folder does not
    // occupy a full four-cell width.
    readonly property real minimumWidth: 0
    readonly property real maximumWidth: screenWidth - (verticalDock ? Panel.rootObject.width + 30 : 20)
    readonly property real maximumHeight: screenHeight - (verticalDock ? 20 : Panel.rootObject.height + 30)
    width: hasProviderContent
            ? Math.max(1, Math.min(maximumWidth, contentLoader.item ? contentLoader.item.implicitWidth : 320))
            : Math.min(Math.max(minimumWidth, columns * cellWidth + 24), maximumWidth)
    height: hasProviderContent
            ? Math.max(1, Math.min(maximumHeight, contentLoader.item ? contentLoader.item.implicitHeight : 120))
            : Math.min(Math.min(3, rows) * cellHeight + 56, maximumHeight)
    contentReady: hasProviderContent ? contentLoader.status !== Loader.Loading : true
    popupX: Math.max(screenX - Panel.rootObject.x + 10,
                     Math.min(positionerAnchor.DockPanelPositioner.x, screenX + screenWidth - Panel.rootObject.x - width - 10))
    popupY: Math.max(screenY - Panel.rootObject.y + 10,
                     Math.min(positionerAnchor.DockPanelPositioner.y, screenY + screenHeight - Panel.rootObject.y - height - 10))
    closeOnInactive: !interactionActive && !Panel.contextDragging

    function openAt(point) {
        anchorPoint = point
        flick.contentY = 0
        open()
    }

    onPresentationChanged: {
        const url = presentation ? presentation.contentUrl : ""
        contentLoader.setSource(url, url ? {presentation: presentation} : {})
    }

    Item {
        anchors.fill: parent
        Binding {
            target: root.positionerAnchor.DockPanelPositioner
            property: "bounding"
            value: Qt.rect(root.anchorPoint.x, root.anchorPoint.y, root.width, root.height)
        }
        Loader {
            id: contentLoader
            objectName: "providerContentLoader"
            anchors.fill: parent
            active: root.hasProviderContent
        }
        Label {
            anchors.fill: parent
            visible: root.hasProviderContent && (contentLoader.status === Loader.Error || contentLoader.status === Loader.Null)
            text: qsTr("Content unavailable")
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
        Connections {
            target: contentLoader.item
            ignoreUnknownSignals: true
            function onCloseRequested() { root.close() }
        }
        Item {
            anchors.fill: parent
            visible: !root.hasProviderContent
            Text {
                anchors.top: parent.top
                anchors.topMargin: 12
                anchors.horizontalCenter: parent.horizontalCenter
                width: parent.width - 32
                height: 28
                text: root.folderName
                textFormat: Text.PlainText
                color: D.DTK.palette.windowText
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
                font: D.DTK.fontManager.t6
            }
            Flickable {
                Accessible.id: "FolderPopup_Flickable"
                id: flick
                anchors.fill: parent
                anchors.topMargin: 44
                anchors.bottomMargin: 12
                anchors.leftMargin: 12
                anchors.rightMargin: 2
                contentWidth: width
                contentHeight: root.rows * root.cellHeight - root.rowSpacing
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                flickableDirection: Flickable.VerticalFlick
                ScrollBar.vertical: ScrollBar {
                    Accessible.id: "FolderPopup_ScrollBar"
                    policy: ScrollBar.AsNeeded
                }
                Grid {
                    columns: root.columns
                    columnSpacing: root.columnSpacing
                    rowSpacing: root.rowSpacing
                    Repeater {
                        model: root.contents
                        ItemDelegate {
                            Accessible.id: "FolderPopup_ItemDelegate"
                            id: entryDelegate
                            required property var modelData
                            width: root.hoverWidth
                            height: root.hoverHeight
                            leftPadding: (root.hoverWidth - root.itemWidth) / 2
                            rightPadding: leftPadding
                            topPadding: (root.hoverHeight - root.itemHeight) / 2
                            bottomPadding: topPadding
                            Accessible.name: modelData.name
                            onClicked: root.activated(modelData)
                            background: AppItemBackground {
                                radius: 8
                                enabled: false
                                D.ColorSelector.hovered: entryDelegate.hovered
                                D.ColorSelector.pressed: entryDelegate.down
                            }
                            contentItem: Item {
                                D.DciIcon {
                                    anchors.top: parent.top
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    width: 48
                                    height: 48
                                    sourceSize: Qt.size(width, height)
                                    name: entryDelegate.modelData.iconName

                                    D.DciIcon {
                                        anchors.left: parent.left
                                        anchors.bottom: parent.bottom
                                        name: "emblem_autostart"
                                        visible: !!entryDelegate.modelData.autoStart
                                        sourceSize: Qt.size(16, 16)
                                        palette: D.DTK.makeIconPalette(entryDelegate.palette)
                                        theme: D.ApplicationHelper.DarkType
                                    }
                                }
                                Text {
                                    anchors.bottom: parent.bottom
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    width: parent.width
                                    height: 36
                                    text: entryDelegate.modelData.name
                                    textFormat: Text.PlainText
                                    wrapMode: Text.Wrap
                                    maximumLineCount: 2
                                    elide: Text.ElideRight
                                    horizontalAlignment: Text.AlignHCenter
                                    color: D.DTK.palette.windowText
                                    font: D.DTK.fontManager.t8
                                }
                            }
                            TapHandler {
                                acceptedButtons: Qt.RightButton
                                onTapped: root.contextMenuRequested(entryDelegate.modelData)
                            }
                        }
                    }
                }
            }
        }
    }
}

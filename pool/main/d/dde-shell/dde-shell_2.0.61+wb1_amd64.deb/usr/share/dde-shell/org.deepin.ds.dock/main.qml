// SPDX-FileCopyrightText: 2023 - 2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.15
import QtQuick.Controls 2.4
import QtQuick.Layouts 2.15
import QtQuick.Window 2.15

import QtQml
import Qt.labs.platform as LP

import org.deepin.ds 1.0
import org.deepin.ds.dock 1.0
import org.deepin.dtk 1.0 as D
import org.deepin.dtk.style 1.0 as DStyle

Window {
    id: dock
    property int positionForAnimation: Panel.position
    property bool useColumnLayout: positionForAnimation % 2

    property alias fashionDock: fashionDockState
    // X11 window moves/resizes are asynchronous to scene rendering. Keep one
    // coordinate space across mode switches, including their first/last frames.
    readonly property bool useFullWidthWindow: !compositorDrivenResize && !useColumnLayout
    readonly property rect dockContentRect: useFullWidthWindow
        ? Qt.rect(dockContainer.x, dockContainer.y, dockContainer.width, dockContainer.height)
        : Qt.rect(0, 0, 0, 0)
    onDockContentRectChanged: updateInputRegion()

    function updateInputRegion() {
        if (!useFullWidthWindow) {
            DLayerShellWindow.setInputRegionRect(0, 0, 0, 0)
            return
        }
        if (!dockTransform)
            return
        DLayerShellWindow.setInputRegionRect(
            Math.round(dockContentRect.x + dockTransform.x), Math.round(dockContentRect.y + dockTransform.y),
            Math.round(dockContentRect.width), Math.round(dockContentRect.height))
    }

    DockModeTransition {
        id: modeTransition
        targetAlignment: Panel.itemAlignment
        animationAllowed: dock.visible && Panel.hideState === Dock.Show
            && !dock.useColumnLayout && dock.positionForAnimation === Panel.position
            && !dock.isDragging && !Applet.isResizing
            && !hideShowAnimation.running && !dockAnimation.running

        dockContent: dockContainer
        contentLayout: gridLayout
        iconContainer: dockCenterPart
        expandedDockWidth: Screen.width
        fashionDockWidth: fashionDock.width
        trailingAreaWidth: dockRightPart.visible
            ? dockRightPart.implicitWidth + Math.ceil(gridLayout.columnSpacing) : 0
        leftAlignedIconX: gridLayout.itemMargin

        onTransitionPreparing: {
            hideTimer.stop()
            Panel.requestClosePopup()
            dock.viewDeactivated()
        }
    }

    QtObject {
        id: fashionDockState

        readonly property bool enabled: !dock.useColumnLayout
            && modeTransition.effectiveAlignment === Dock.FashionAlignment
        readonly property int floatingMargin: 8
        readonly property real animatedFloatingMargin: modeTransition.transitionActive
            ? floatingMargin * (1 - modeTransition.widthExpansionProgress) : (enabled ? floatingMargin : 0)
        readonly property real animatedBackgroundRadius: backgroundRadius
            * animatedFloatingMargin / floatingMargin
        readonly property int backgroundRadius: {
            const verticalPadding = Math.max(6, Math.round(dock.dockSize * 0.16))
            return Math.round((dock.dockSize + verticalPadding * 2) / 4)
        }
        readonly property int width: {
            if (!enabled)
                return 1
            const rightWidth = dockRightPart.visible ? dockRightPart.implicitWidth
                + (gridLayout.implicitWidth > 0 ? gridLayout.columnSpacing : 0) : 0
            return Math.max(1, Math.round(Math.min(gridLayout.implicitWidth + rightWidth,
                Math.max(1, Screen.width - floatingMargin * 2))))
        }
    }
    property int dockCenterPartCount: dockCenterPartModel.count
    readonly property int centerAlignmentEdgeSpacing: Panel.fashionModeEnabled ? 14 : 20

    function centeredIconMargin(layoutExtent, iconExtent, leadingExtent, trailingExtent) {
        const centeredSideSpace = (layoutExtent - iconExtent) / 2
        return Math.max(0, centeredSideSpace - (leadingExtent + centerAlignmentEdgeSpacing)
            + Math.min(centeredSideSpace - (trailingExtent + centerAlignmentEdgeSpacing), 0))
    }

    readonly property int dockRawCenterSpace: {
        if (useColumnLayout) {
            return Screen.height - dockLeftPart.implicitHeight - dockRightPart.implicitHeight;
        } else {
            let space = Screen.width - dockLeftPart.implicitWidth - dockRightPart.implicitWidth;
            if (Panel.fashionModeEnabled)
                space -= Math.ceil(gridLayout.columnSpacing);
            if (fashionDock.enabled && gridLayout) {
                // 时尚模式下，dockRightPart 在 gridLayout 右侧，之间需要扣除 dockSpacing
                // 同时保留左右悬浮间距，避免窗口铺满屏幕后圆角边框被屏幕边缘裁剪。
                space -= Math.ceil(gridLayout.columnSpacing) * 2 + fashionDock.floatingMargin * 2;
            }
            return Math.max(0, space);
        }
    }
    readonly property int dockEffectiveCenterSpace: {
        if (!Panel.fashionModeEnabled || modeTransition.effectiveAlignment !== Dock.CenterAlignment) {
            return dockRawCenterSpace
        }

        const screenExtent = useColumnLayout ? Screen.height : Screen.width
        const leftExtent = useColumnLayout ? dockLeftPart.implicitHeight : dockLeftPart.implicitWidth
        const rightExtent = useColumnLayout ? dockRightPart.implicitHeight : dockRightPart.implicitWidth
        return Math.max(0, screenExtent - leftExtent - rightExtent
                        - centerAlignmentEdgeSpacing * 2)
    }

    property int dockPartSpacing: gridLayout.columnSpacing
    // TODO
    signal dockCenterPartPosChanged()
    signal pressedAndDragging(bool isDragging)
    signal viewDeactivated()

    property int dockSize: Applet.dockSize
    property int dockItemMaxSize: dockSize
    property int itemIconSizeBase: 0
    property int itemSpacing: 0

    property bool isDragging: false
    property bool initialized: false
    readonly property bool initialSizeReady: !fashionDock.enabled
        || (dockCenterPartCount > 0 && dockCenterPart.implicitWidth > 1)
    onInitialSizeReadyChanged: {
        if (initialSizeReady && !initialized)
            Qt.callLater(finishInitialization)
    }

    function finishInitialization() {
        if (initialized || !initialSizeReady)
            return
        initialized = true
        dock.visible = Panel.hideState !== Dock.Hide
    }

    readonly property bool compositorDrivenResize: Qt.platform.pluginName !== "xcb"

    property real dockItemIconSize: dockItemMaxSize * 9 / 14

    width: useColumnLayout ? dockSize : (useFullWidthWindow ? Screen.width : dockContainer.implicitWidth)
    height: useColumnLayout
        ? (compositorDrivenResize ? Screen.height : -1)
        : dockSize
    color: "transparent"
    flags: Qt.WindowDoesNotAcceptFocus
    // X11 resizes the dock explicitly. Keep both size limits synchronized
    // when resizing or switching orientation. Floating margins stay outside
    // the window so consumers can use its size as the dock thickness.
    maximumHeight: useColumnLayout ? Screen.height
        : (compositorDrivenResize ? Dock.MAX_DOCK_SIZE : dockSize)
    minimumHeight: !compositorDrivenResize ? maximumHeight
        : (useColumnLayout ? Screen.height : (isDragging ? Dock.MIN_DOCK_SIZE : 1))
    maximumWidth: useColumnLayout ? (compositorDrivenResize ? Dock.MAX_DOCK_SIZE : dockSize) : Screen.width
    minimumWidth: !compositorDrivenResize ? maximumWidth
        : (useColumnLayout ? (isDragging ? Dock.MIN_DOCK_SIZE : 1)
            : (fashionDock.enabled || modeTransition.transitionActive ? 1 : Screen.width))

    function blendColorAlpha(fallback) {
        var appearance = DS.applet("org.deepin.ds.dde-appearance")
        if (!appearance || appearance.opacity < 0)
            return fallback
        return appearance.opacity
    }

    function requestShowDockMenu() {
        if (!Panel.contextMenuEnabled)
            return

        // maybe has popup visible, close it.
        Panel.requestClosePopup()
        viewDeactivated()
        hideTimer.stop()
        MenuHelper.openMenu(dockMenuLoader.item)
    }

    DLayerShellWindow.anchors: (fashionDock.enabled || modeTransition.transitionActive) && !useFullWidthWindow
        ? (positionForAnimation === Dock.Top ? DLayerShellWindow.AnchorTop : DLayerShellWindow.AnchorBottom)
        : position2Anchors(positionForAnimation)
    DLayerShellWindow.topMargin: positionForAnimation === Dock.Top
        ? Math.round(fashionDock.animatedFloatingMargin)
        : 0

    DLayerShellWindow.bottomMargin: positionForAnimation === Dock.Bottom
        ? Math.round(fashionDock.animatedFloatingMargin)
        : 0
    DLayerShellWindow.layer: DLayerShellWindow.LayerTop
    DLayerShellWindow.exclusionZone: Panel.hideMode === Dock.KeepShowing
        ? Applet.dockSize + Math.round(fashionDock.animatedFloatingMargin)
        : 0
    DLayerShellWindow.scope: "dde-shell/dock"
    DLayerShellWindow.keyboardInteractivity: DLayerShellWindow.KeyboardInteractivityNone

    D.DWindow.enabled: true
    D.DWindow.windowRadius: useFullWidthWindow ? 0 : Math.round(fashionDock.animatedBackgroundRadius)
    //TODO：由于windoweffect处理有BUG，导致动画结束后一致保持无阴影，无borderwidth状态。 无法恢复到最初的阴影和边框
    //D.DWindow.windowEffect: hideShowAnimation.running ? D.PlatformHandle.EffectNoShadow | D.PlatformHandle.EffectNoBorder : 0
    
    // 目前直接处理shadowColor(透明和默认值的切换)和borderWidth(0和1的切换)，来控制阴影和边框
    // 参数默认值见： https://github.com/linuxdeepin/qt5platform-plugins/blob/master/xcb/dframewindow.h#L122
    // 需要注意，shadowRadius不能直接套用于“扩散”参数，拿到不透明度100%的设计图确定radius更合适一些。
    D.DWindow.shadowColor: (useFullWidthWindow || hideShowAnimation.running || dockAnimation.running) ? Qt.rgba(0, 0, 0, 0) : Qt.rgba(0, 0, 0, 0.1)
    D.DWindow.shadowOffset: Qt.point(0, 0)
    D.DWindow.shadowRadius: 40
    D.DWindow.borderWidth:  (useFullWidthWindow || hideShowAnimation.running || dockAnimation.running) ? 0 : 1
    D.DWindow.enableBlurWindow: Qt.platform.pluginName !== "xcb"
    D.DWindow.themeType: Panel.colorTheme
    D.DWindow.borderColor: D.DTK.themeType === D.ApplicationHelper.DarkType ? Qt.rgba(0, 0, 0, dock.blendColorAlpha(0.6) + 20 / 255) : Qt.rgba(0, 0, 0, 0.15)
    D.ColorSelector.family: D.Palette.CrystalColor

    // 指示器样式只跟任务栏尺寸相关，三种模式保持一致：
    // 拉到最小尺寸时用高效模式的指示器（应用图标带背景），其他尺寸用时尚模式的圆点指示器。
    onDockSizeChanged: {
        if (dock.dockSize === Dock.MIN_DOCK_SIZE) {
            Panel.indicatorStyle = Dock.Efficient
        } else {
            Panel.indicatorStyle = Dock.Fashion
        }
    }
    Binding on itemIconSizeBase {
        when: !isDragging
        value: dockItemMaxSize
        restoreMode: Binding.RestoreNone
    }

    PropertyAnimation {
        id: hideShowAnimation;
        // Currently, Wayland (Treeland) doesn't support StyledBehindWindowBlur inside the window, thus we keep using the window size approach on Wayland
        property bool useTransformBasedAnimation: Qt.platform.pluginName === "xcb"
        property bool targetIsHidden: false
        target: useTransformBasedAnimation ? dockTransform : dock;
        property: {
            if (useTransformBasedAnimation) return dock.useColumnLayout ? "x" : "y";
            return dock.useColumnLayout ? "width" : "height";
        }
        to: {
            if (useTransformBasedAnimation) return Panel.hideState !== Dock.Hide ? 0 : ((dock.positionForAnimation === Dock.Left || dock.positionForAnimation === Dock.Top) ? -Panel.dockSize : Panel.dockSize);
            return Panel.hideState !== Dock.Hide ? Panel.dockSize : 1;
        }
        duration: 500
        easing.type: Easing.OutCubic
        onStarted: {
            targetIsHidden = Panel.hideState === Dock.Hide
            dock.visible = true
        }
        onStopped: {
            if (useTransformBasedAnimation) {
                dock.visible = ((dock.useColumnLayout ? dockTransform.x : dockTransform.y) === 0)
            } else if (!dock.compositorDrivenResize) {
                dock.visible = ((dock.useColumnLayout ? dock.width : dock.height) !== 1)
            }
        }
        onFinished: {
            // A late Wayland configure may still report the hidden size.
            if (dock.compositorDrivenResize)
                dock.visible = !targetIsHidden
        }
    }

    Connections {
        target: dockTransform
        enabled: hideShowAnimation.useTransformBasedAnimation && hideShowAnimation.running
        
        function onXChanged() {
            if (dock.useColumnLayout) {
                Panel.notifyDockPositionChanged(dockTransform.x, 0)
            }
        }
        
        function onYChanged() {
            if (!dock.useColumnLayout) {
                Panel.notifyDockPositionChanged(0, dockTransform.y)
            }
        }
    }

    Connections {
        target: dock
        enabled: !hideShowAnimation.useTransformBasedAnimation && hideShowAnimation.running
        
        function onWidthChanged() {
            if (dock.useColumnLayout) {
                Panel.notifyDockPositionChanged(dock.width, 0)
            }
        }
        
        function onHeightChanged() {
            if (!dock.useColumnLayout) {
                Panel.notifyDockPositionChanged(0, dock.height)
            }
        }
    }

    Timer {
        id: hideTimer
        interval: 500
        running: false
        repeat: false
        onTriggered: {
            if (!dock.isDragging && !MenuHelper.activeMenu)
                hideShowAnimation.start()
        }
    }

    SequentialAnimation {
        id: dockAnimation
        property bool useTransformBasedAnimation: Qt.platform.pluginName === "xcb"
        property bool isShowing: false
        property bool isPositionChanging: false
        property var target: useTransformBasedAnimation ? dockTransform : dock
        property string animProperty: {
            if (useTransformBasedAnimation) return dock.useColumnLayout ? "x" : "y";
            return dock.useColumnLayout ? "width" : "height";
        }

        function startAnimation(showing) {
            isShowing = showing;
            start();
        }

        function setTransformToHiddenPosition() {
            if (useTransformBasedAnimation) {
                var hideOffset = (Panel.position === Dock.Left || Panel.position === Dock.Top) ? -Panel.dockSize : Panel.dockSize;
                if (dock.useColumnLayout) {
                    dockTransform.x = hideOffset;
                    dockTransform.y = 0;
                } else {
                    dockTransform.x = 0;
                    dockTransform.y = hideOffset;
                }
            } else {
                dockTransform.x = 0;
                dockTransform.y = 0;
            }
        }

        PropertyAnimation {
            target: dockAnimation.target
            property: dockAnimation.animProperty
            from: {
                if (dockAnimation.isShowing) {
                    if (dockAnimation.useTransformBasedAnimation) {
                        return (dock.positionForAnimation === Dock.Left || dock.positionForAnimation === Dock.Top) ? -Panel.dockSize : Panel.dockSize;
                    }
                    return 1;
                }
                return dockAnimation.useTransformBasedAnimation ? 0 : Panel.dockSize;
            }
            to: {
                if (dockAnimation.isShowing) {
                    return dockAnimation.useTransformBasedAnimation ? 0 : Panel.dockSize;
                } else {
                    if (dockAnimation.useTransformBasedAnimation) {
                        return (dock.positionForAnimation === Dock.Left || dock.positionForAnimation === Dock.Top) ? -Panel.dockSize : Panel.dockSize;
                    }
                    return 1;
                }
            }
            duration: 250
            easing.type: Easing.OutCubic
        }

        onStarted: {
            dock.visible = true;
        }

        onStopped: {
            if (useTransformBasedAnimation) {
                dock.visible = true;
            } else {
                dock.visible = ((dock.useColumnLayout ? dock.width : dock.height) !== 1);
            }

            dock.positionForAnimation = Panel.position;
            changeDragAreaAnchor()
            // If this was a hide animation during position change, prepare for show animation
            if (isPositionChanging && !isShowing) {
                isPositionChanging = false;

                // Set transform to hidden position before showing
                setTransformToHiddenPosition();

                startAnimation(true);
            } else if (isShowing && Panel.hideState === Dock.Hide) {
                // Restore the backend-requested hidden state after the
                // position-change show animation has completed.
                hideTimer.restart();
            }
        }
    }

    component EnumPropertyMenuItem: LP.MenuItem {
        required property string name
        required property string prop
        required property int value
        text: name

        onTriggered: {
            Applet[prop] = value
            checked = Qt.binding(function() {
                return Applet[prop] === value
            })
        }
        checked: Applet[prop] === value
    }
    component MutuallyExclusiveMenu: LP.Menu {
        id: menu
        LP.MenuItemGroup {
            id: group
            items: menu.items
        }
    }

    function updateAppItems()
    {
        dockLeftPartModel.update()
        dockCenterPartModel.update()
        dockRightPartModel.update()
    }

    Loader {
        id: dockMenuLoader
        active: false
        sourceComponent: LP.Menu {
            id: dockMenu
            MutuallyExclusiveMenu {
                visible: Panel.debugMode
                title: qsTr("Indicator Style")
                EnumPropertyMenuItem {
                    name: qsTr("Fashion Mode")
                    prop: "indicatorStyle"
                    value: Dock.Fashion
                }
                EnumPropertyMenuItem {
                    name: qsTr("Efficient Mode")
                    prop: "indicatorStyle"
                    value: Dock.Efficient
                }
            }
            MutuallyExclusiveMenu {
                title: qsTr("Mode")
                EnumPropertyMenuItem {
                    name: qsTr("Classic Mode")
                    prop: "itemAlignment"
                    value: Dock.LeftAlignment
                }
                EnumPropertyMenuItem {
                    name: qsTr("Centered Mode")
                    prop: "itemAlignment"
                    value: Dock.CenterAlignment
                }
                EnumPropertyMenuItem {
                    name: qsTr("Fashion Mode")
                    prop: "itemAlignment"
                    value: Dock.FashionAlignment
                    // 由 DConfig 的 enableFashionMode 控制时尚模式入口是否显示
                    visible: Panel.fashionModeEnabled
                }
            }
            MutuallyExclusiveMenu {
                title: qsTr("Position")
                // Fashion mode only allows top/bottom. Hide the left/right items
                // from the context menu so the user can only pick supported edges.
                EnumPropertyMenuItem {
                    name: qsTr("Top")
                    prop: "position"
                    value: Dock.Top
                }
                EnumPropertyMenuItem {
                    name: qsTr("Bottom")
                    prop: "position"
                    value: Dock.Bottom
                }
                EnumPropertyMenuItem {
                    name: qsTr("Left")
                    prop: "position"
                    value: Dock.Left
                    visible: !fashionDock.enabled
                }
                EnumPropertyMenuItem {
                    name: qsTr("Right")
                    prop: "position"
                    value: Dock.Right
                    visible: !fashionDock.enabled
                }
            }
            MutuallyExclusiveMenu {
                title: qsTr("Status")
                EnumPropertyMenuItem {
                    name: qsTr("Keep Shown")
                    prop: "hideMode"
                    value: Dock.KeepShowing
                }
                EnumPropertyMenuItem {
                    name: qsTr("Keep Hidden")
                    prop: "hideMode"
                    value: Dock.KeepHidden
                }
                EnumPropertyMenuItem {
                    name: qsTr("Smart Hide")
                    prop: "hideMode"
                    value: Dock.SmartHide
                }
            }
            LP.MenuItem {
                text: qsTr("Lock the Dock")
                checked: Panel.locked
                onTriggered: {
                    Panel.locked = !Panel.locked
                }
            }
            LP.MenuItem {
                text: qsTr("Dock Settings")
                onTriggered: {
                    Panel.openDockSettings()
                }
            }
        }
    }

    Connections {
        target: Panel
        function onContextMenuEnabledChanged() {
            if (Panel.contextMenuEnabled)
                return

            if (MenuHelper.activeMenu === dockMenuLoader.item)
                MenuHelper.closeCurrent()
            dockMenuLoader.active = false
        }
    }

    Item {
        id: dockContainer
        Accessible.id: "main_Item"
        implicitWidth: modeTransition.transitionActive ? modeTransition.animatedDockWidth
            : fashionDock.enabled ? fashionDock.width : Screen.width
        width: dock.useColumnLayout ? dock.dockSize
            : (dock.useFullWidthWindow ? implicitWidth : parent.width)
        height: dock.useColumnLayout ? parent.height : dock.dockSize
        x: dock.useFullWidthWindow ? (dock.width - width) / 2 : 0
        property bool touchLongPressed: false
        transform: Translate {
            id: dockTransform
            onXChanged: dock.updateInputRegion()
            onYChanged: dock.updateInputRegion()
            Component.onCompleted: dock.updateInputRegion()
        }

        D.BoxShadow {
            anchors.fill: parent
            visible: dock.useFullWidthWindow && !hideShowAnimation.running && !dockAnimation.running
            shadowBlur: dock.D.DWindow.shadowRadius
            shadowColor: Qt.rgba(0, 0, 0, 0.1)
            cornerRadius: fashionDock.animatedBackgroundRadius
            hollow: true
        }

        // only add blendColor effect when DWindow.enableBlurWindow is true,
        // avoid to updating blur area frequently.--
        D.StyledBehindWindowBlur {
            control: parent
            anchors.fill: parent
            cornerRadius: fashionDock.animatedBackgroundRadius
            blendColor: {
                if (valid) {
                    return DStyle.Style.control.selectColor(undefined,
                                                        Qt.rgba(235 / 255.0, 235 / 255.0, 235 / 255.0, dock.blendColorAlpha(0.6)),
                                                        Qt.rgba(10 / 255, 10 / 255, 10 /255, dock.blendColorAlpha(85 / 255)))
                }
                return DStyle.Style.control.selectColor(undefined,
                                                    DStyle.Style.behindWindowBlur.lightNoBlurColor,
                                                    DStyle.Style.behindWindowBlur.darkNoBlurColor)
            }
        }

        Rectangle {
            anchors.fill: parent
            visible: dock.useFullWidthWindow && !hideShowAnimation.running && !dockAnimation.running
            color: "transparent"
            radius: fashionDock.animatedBackgroundRadius
            border.width: 1
            border.color: dock.D.DWindow.borderColor
        }

        Loader {
            anchors.fill: parent
            active: dock.fashionDock.enabled && Panel.hideState === Dock.Show && !modeTransition.transitionActive
            sourceComponent: DockSpotlight {
                Accessible.id: "main_Pane"
                containsMouse: Panel.containsMouse
                cursorPosition: dockContainer.mapFromItem(null, Panel.cursorPosition)
                itemSize: dock.dockItemMaxSize
                darkTheme: Panel.colorTheme === Dock.Dark
            }
        }

        TapHandler {
            acceptedButtons: Qt.LeftButton | Qt.RightButton
            gesturePolicy: TapHandler.WithinBounds
            onTapped: function(eventPoint, button) {
                let lastActive = MenuHelper.activeMenu
                MenuHelper.closeCurrent()
                if (button === Qt.RightButton && Panel.contextMenuEnabled) {
                    dockMenuLoader.active = true
                }
                if (button === Qt.RightButton && Panel.contextMenuEnabled && lastActive !== dockMenuLoader.item) {
                    requestShowDockMenu()
                }
                if (button === Qt.LeftButton) {
                    // try to close popup when clicked empty, because dock does not have focus.
                    Panel.requestClosePopup()
                    viewDeactivated()
                }
            }
        }

        //Touch screen click
        TapHandler {
            acceptedButtons: Qt.NoButton
            acceptedDevices: PointerDevice.TouchScreen
            onTapped: function(eventPoint, button) {
                if (dockContainer.touchLongPressed) {
                    dockContainer.touchLongPressed = false
                    return
                }
                let lastActive = MenuHelper.activeMenu
                MenuHelper.closeCurrent()
                // try to close popup when clicked empty, because dock does not have focus.
                Panel.requestClosePopup()
                viewDeactivated()
            }
            onLongPressed: {
                dockContainer.touchLongPressed = true
                let lastActive = MenuHelper.activeMenu
                MenuHelper.closeCurrent()
                if (Panel.contextMenuEnabled) {
                    dockMenuLoader.active = true
                }
                if (Panel.contextMenuEnabled && lastActive !== dockMenuLoader.item) {
                    requestShowDockMenu()
                }
            }
            onCanceled: {
                dockContainer.touchLongPressed = false
            }
        }

        HoverHandler {
            cursorShape: Qt.ArrowCursor
        }

        // TODO missing property binding to update ProxyModel's filter and sort opearation.
        Repeater {
            model: Applet.appletItems
            delegate: Item {
                property var order: model.data.dockOrder
                property bool itemVisible: model.data.shouldVisible === undefined || model.data.shouldVisible

                onItemVisibleChanged: {
                    updateAppItems()
                }
                onOrderChanged: {
                    updateAppItems()
                }
            }
        }
        //此处为边距区域的点击实践特殊处理。
        MouseArea {                                                                                                                                     
            id: leftMarginArea                                                                                                                          
            width: useColumnLayout ? parent.width : (fashionDock.enabled ? 0 : gridLayout.columnSpacing)
            height: useColumnLayout ? gridLayout.rowSpacing : parent.height                                                                             
            anchors.left: parent.left
            anchors.top: parent.top
            onClicked: {
                let minOrder = Number.MAX_VALUE
                
                for (let i = 0; i < Applet.appletItems.rowCount(); i++) {
                    let itemData = Applet.appletItems.data(Applet.appletItems.index(i, 0), Qt.UserRole + 1)
                    if (itemData && itemData.dockOrder < minOrder) {
                        minOrder = itemData.dockOrder
                    }
                }
                Panel.leftEdgeClicked(minOrder)
            }                                                                       
        } 
        // TODO: remove GridLayout and use delegatechosser manager all items
        GridLayout {
            id: gridLayout
            anchors {
                fill: parent
                // Centered mode uses its final layout throughout expansion.
                // The icon transform alone interpolates from the old position.
                rightMargin: modeTransition.transitionActive
                    ? parent.width - modeTransition.transitionLayoutWidth
                    : (fashionDock.enabled && dockRightPart.visible
                        ? dockRightPart.implicitWidth + Math.ceil(gridLayout.columnSpacing) : 0)
            }
            columns: 1
            rows: 1
            flow: useColumnLayout ? GridLayout.LeftToRight : GridLayout.TopToBottom
            property real itemMargin: Math.max((dockItemIconSize / 48 * 10))
            columnSpacing: fashionDock.enabled
                ? dockItemIconSize
                : (dockLeftPartModel.count > 0 ? 10 : itemMargin)
            rowSpacing: columnSpacing

            Item {
                id: leftMargin
                visible: !fashionDock.enabled
                implicitWidth: 0
                implicitHeight: 0
            }

            Item {
                id: dockLeftPart
                visible: dockLeftPartModel.count > 0
                implicitWidth: leftLoader.implicitWidth
                implicitHeight: leftLoader.implicitHeight
                Accessible.role: Accessible.Grouping
                Accessible.name: qsTr("Dock Left Area")
                OverflowContainer {
                    Accessible.role: Accessible.Pane
                    Accessible.id: "LeftLoader"
                    id: leftLoader
                    anchors.fill: parent
                    useColumnLayout: dock.useColumnLayout
                    model: DockPartAppletModel {
                        id: dockLeftPartModel
                        leftDockOrder: 0
                        rightDockOrder: 10
                    }
                }
            }

            Item {  
                id: dockCenterPart
                transform: Translate {
                    // Compensate for the moving window origin so expansion
                    // alone does not move the icons before their animation starts.
                    x: modeTransition.iconTranslationX
                    onXChanged: dock.dockCenterPartPosChanged()
                }
                implicitWidth: centerLoader.implicitWidth
                implicitHeight: centerLoader.implicitHeight
                Accessible.role: Accessible.Grouping
                Accessible.name: qsTr("Dock Center Area")
                Layout.maximumWidth: useColumnLayout ? -1 : dockEffectiveCenterSpace
                Layout.maximumHeight: useColumnLayout ? dockEffectiveCenterSpace : -1
                onXChanged: dockCenterPartPosChanged()
                onYChanged: dockCenterPartPosChanged()
                Layout.leftMargin: {
                    if (!useColumnLayout && fashionDock.enabled) {
                        return dockLeftPart.visible ? 0 : Math.max(10, Math.round(dockItemIconSize) / 3)
                    }
                    return !useColumnLayout && modeTransition.effectiveAlignment === Dock.CenterAlignment ?
                        dock.centeredIconMargin(gridLayout.width, dockCenterPart.implicitWidth,
                            dockLeftPart.implicitWidth, dockRightPart.implicitWidth) : 0
                }
                Layout.topMargin: useColumnLayout && modeTransition.effectiveAlignment === Dock.CenterAlignment ?
                    dock.centeredIconMargin(dock.height, dockCenterPart.implicitHeight,
                        dockLeftPart.implicitHeight, dockRightPart.implicitHeight) : 0

                Behavior on Layout.leftMargin {
                    enabled: !dock.isDragging && !Applet.isResizing && !modeTransition.transitionActive
                    NumberAnimation {
                        duration: 200
                        easing.type: Easing.OutCubic
                    }
                }

                Behavior on Layout.topMargin {
                    enabled: !dock.isDragging && !Applet.isResizing && !modeTransition.transitionActive
                    NumberAnimation {
                        duration: 200
                        easing.type: Easing.OutCubic
                    }
                }

                OverflowContainer {
                    Accessible.id: "main_Pane_8"
                    Accessible.role: Accessible.Pane
                    id: centerLoader
                    anchors.fill: parent
                    useColumnLayout: dock.useColumnLayout
                    spacing: dock.itemSpacing
                    model: DockPartAppletModel {
                        id: dockCenterPartModel
                        leftDockOrder: 10
                        rightDockOrder: 20
                    }
                }
            }

            Item {
                Layout.fillWidth: !fashionDock.enabled
                Layout.fillHeight: !fashionDock.enabled
                visible: !fashionDock.enabled
            }
        }

        Item {
            Accessible.id: "main_Pane_12"
            id: dockRightPart
            implicitWidth: rightLoader.implicitWidth
            implicitHeight: rightLoader.implicitHeight
            Accessible.role: Accessible.Grouping
            Accessible.name: qsTr("Dock Right Area")
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            OverflowContainer {
                Accessible.role: Accessible.Pane
                Accessible.id: "RightLoader"
                id: rightLoader
                anchors.fill: parent
                useColumnLayout: dock.useColumnLayout
                model: DockPartAppletModel {
                    id: dockRightPartModel
                    leftDockOrder: 20
                    rightDockOrder: 30
                }
            }
        }
    }

    MouseArea {
        id: dragArea
        parent: dock.useFullWidthWindow ? dockContainer : dock.contentItem
        property point oldMousePos: Qt.point(0, 0)
        property int oldDockSize: 0
        property list<int> recentDeltas: []
        property int averageCount: 5
        hoverEnabled: true
        propagateComposedEvents: true
        enabled: !Panel.locked && !modeTransition.transitionActive

        cursorShape: {
            if (Panel.locked) {
                return Qt.ArrowCursor
            }
            if (Panel.position === Dock.Top || Panel.position === Dock.Bottom) {
                return Qt.SizeVerCursor
            }
            return Qt.SizeHorCursor
        }

        onPressed: function(mouse) {
            if (Panel.locked) return
            dock.isDragging = true
            oldMousePos = mapToGlobal(mouse.x, mouse.y)
            oldDockSize = dockSize
            recentDeltas = []
            Panel.requestClosePopup()
            
            if (dock.compositorDrivenResize) {
                const edge = Panel.position === Dock.Top ? Qt.BottomEdge
                    : Panel.position === Dock.Bottom ? Qt.TopEdge
                    : Panel.position === Dock.Left ? Qt.RightEdge : Qt.LeftEdge
                if (!dock.startSystemResize(edge))
                    finishResize()
                return
            }
            DS.grabMouse(Panel.rootObject, true)
        }

        // this used for blocking MouseEvent sent to bottom MouseArea
        onClicked: {}

        onPositionChanged: function(mouse) {
            if (Panel.locked || !dock.isDragging) return

            if (dock.compositorDrivenResize) return

            var newPos = mapToGlobal(mouse.x, mouse.y)
            var xChange = newPos.x - oldMousePos.x
            var yChange = newPos.y - oldMousePos.y

            if (Panel.position === Dock.Bottom || Panel.position === Dock.Top) {
                recentDeltas.push(yChange)
            } else {
                recentDeltas.push(xChange)
            }

            if (recentDeltas.length > averageCount) {
                recentDeltas.shift()
            }
            // Taking the average makes the data smooth without jumps
            var changeAverage = recentDeltas.reduce(function(acc, val) { return acc + val; }, 0) / recentDeltas.length;

            var newDockSize = 0
            if (Panel.position === Dock.Bottom) {
                newDockSize = Math.min(Math.max(oldDockSize - changeAverage, Dock.MIN_DOCK_SIZE), Dock.MAX_DOCK_SIZE)
            } else if (Panel.position === Dock.Top) {
                newDockSize = Math.min(Math.max(oldDockSize + changeAverage, Dock.MIN_DOCK_SIZE), Dock.MAX_DOCK_SIZE)
            } else if (Panel.position === Dock.Left) {
                newDockSize = Math.min(Math.max(oldDockSize + changeAverage, Dock.MIN_DOCK_SIZE), Dock.MAX_DOCK_SIZE)
            } else {
                newDockSize = Math.min(Math.max(oldDockSize - changeAverage, Dock.MIN_DOCK_SIZE), Dock.MAX_DOCK_SIZE)
            }

            if (newDockSize !== dockSize) {
                dockSize = newDockSize
            }

            pressedAndDragging(true)
        }

        onReleased: function(mouse) {
            if (Panel.locked) return
        
            if (dock.DLayerShellWindow.resizing) return

            finishResize()
        }

        onCanceled: {
            if (!dock.DLayerShellWindow.resizing)
                finishResize()
        }

        function finishResize() {
            if (!dock.isDragging) return
            dock.isDragging = false
            Applet.dockSize = dockSize
            itemIconSizeBase = dockItemMaxSize
            pressedAndDragging(false)
            DS.grabMouse(Panel.rootObject, false)
        }

        function anchorToTop() {
            anchors.top = undefined
            anchors.bottom = parent.bottom
            anchors.left = parent.left
            anchors.right = parent.right
            dragArea.height = 5
        }

        function anchorToBottom() {
            anchors.bottom = undefined
            anchors.top = parent.top
            anchors.left = parent.left
            anchors.right = parent.right
            dragArea.height = 5
        }
        function anchorToLeft() {
            anchors.left = undefined
            anchors.right = parent.right
            anchors.bottom = parent.bottom
            anchors.top = parent.top
            dragArea.width = 5
        }
        function anchorToRight() {
            anchors.right = undefined
            anchors.left = parent.left
            anchors.bottom = parent.bottom
            anchors.top = parent.top
            dragArea.width = 5
        }
    }

    Connections {
        target: dock.DLayerShellWindow
        function onResizeFinished(size) {
            Applet.dockSize = dock.useColumnLayout ? size.width : size.height
        }
        function onResizingChanged() {
            if (!dock.DLayerShellWindow.resizing && dock.isDragging) {
                dragArea.finishResize()
            }
        }
    }

    Connections {
        target: dock
        enabled: dock.compositorDrivenResize
            // Wayland can apply animation geometry after the animation stops.
            && dock.isDragging && dock.DLayerShellWindow.resizing
            && !hideShowAnimation.running
            && !dockAnimation.running
        function onWidthChanged() {
            if (dock.useColumnLayout) {
                Applet.dockSize = dock.width
            }
        }

        function onHeightChanged() {
            if (!dock.useColumnLayout) {
                Applet.dockSize = dock.height
            }
        }
    }
    function changeDragAreaAnchor() {
        switch(dock.positionForAnimation) {
        case Dock.Top: {
            dragArea.anchorToTop()
            return
        }
        case Dock.Bottom: {
            dragArea.anchorToBottom()
            return
        }
        case Dock.Left: {
            dragArea.anchorToLeft()
            return
        }
        case Dock.Right:{
            dragArea.anchorToRight()
            return
        }
        }
    }

    Connections {
        function onBeforePositionChanged(beforePosition) {
            modeTransition.finishTransition()
            // Prevent the delayed hide animation from racing the position animation.
            hideTimer.stop();
            // Stop any running animations first
            dockAnimation.stop();
            hideShowAnimation.stop();

            // Set the position for animation to old position for hide animation
            dock.positionForAnimation = beforePosition;

            // Mark that we're changing position
            dockAnimation.isPositionChanging = true;

            // Check if dock is currently hidden
            if (Panel.hideState === Dock.Hide && !dock.visible) {
                // Dock is already hidden, no need for hide animation
                // Wait for onPositionChanged to get the new position, then show
                dockAnimation.isPositionChanging = false;
            } else {
                // Start hide animation at old position
                // When animation completes, onStopped will handle show animation
                dockAnimation.startAnimation(false);
            }
        }

        function onPositionChanged() {
            Panel.requestClosePopup()

            // If dock was hidden when position change started, show it now at new position
            if (!dockAnimation.isPositionChanging && !dock.visible) {
                dock.positionForAnimation = Panel.position;

                // Set transform to hidden position before showing
                dockAnimation.setTransformToHiddenPosition();

                dockAnimation.startAnimation(true);
            }
        }
        function onDockSizeChanged() {
            dock.dockSize = Panel.dockSize
        }

        function onHideStateChanged() {
            if (!dock.initialized)
                return
            if (Panel.hideState === Dock.Hide) {
                hideTimer.restart()
            } else if (Panel.hideState === Dock.Show) {
                hideTimer.stop()

                // Reverse an in-flight hide animation, but do not restart an
                // animation that is already moving towards the shown state.
                if (!hideShowAnimation.running || hideShowAnimation.targetIsHidden || !dock.visible) {
                    hideShowAnimation.restart()
                }
                dock.visible = true
            }
        }
        function onRequestClosePopup() {
            let popup = Panel.popupWindow
            DS.closeChildrenWindows(popup)
            if (popup && popup.visible)
                popup.close()
        }
        function onDockScreenChanged() {
            modeTransition.finishTransition()
            // Close all popups when dock moves to another screen
            Panel.requestClosePopup()
        }

        target: Panel
    }

    Connections {
        function onMenuClosed() {
            // 当右键菜单关闭时，根据当前隐藏模式重新启动隐藏计时器
            if (Panel.hideMode === Dock.KeepHidden
                || Panel.hideMode === Dock.SmartHide
                || Panel.hideState === Dock.Hide) {
                hideTimer.running = true
            }
        }

        target: MenuHelper
    }

    function position2Anchors(position) {
        switch (position) {
        case Dock.Top:
            return DLayerShellWindow.AnchorLeft | DLayerShellWindow.AnchorRight | DLayerShellWindow.AnchorTop
        case Dock.Right:
            return DLayerShellWindow.AnchorTop | DLayerShellWindow.AnchorBottom | DLayerShellWindow.AnchorRight
        case Dock.Bottom:
            return DLayerShellWindow.AnchorLeft | DLayerShellWindow.AnchorRight | DLayerShellWindow.AnchorBottom
        case Dock.Left:
            return DLayerShellWindow.AnchorTop | DLayerShellWindow.AnchorBottom | DLayerShellWindow.AnchorLeft
        }
    }

    // can not move into DockCompositor
    // Panel get a object instead of ds::dock::DockPanel during DockCompositor creating
    Binding {
        target: Panel
        property: "compositorReady"
        value: DockCompositor.compositor.created
        when: DockCompositor.compositor.created
    }

    Component.onCompleted: {
        Panel.toolTipWindow.D.DWindow.themeType = Qt.binding(function(){
            return Panel.colorTheme
        })

        Panel.popupWindow.D.DWindow.themeType = Qt.binding(function(){
            return Panel.colorTheme
        })

        DockCompositor.dockColorTheme = Qt.binding(function(){
            return Panel.colorTheme
        })

        DockCompositor.dockPosition = Qt.binding(function(){
            return dock.positionForAnimation
        })

        DockCompositor.dockSize = Qt.binding(function(){
            return Qt.size(Panel.frontendWindowRect.width, Panel.frontendWindowRect.height)
        })

        // 插件需要知道任务栏是否处于时尚模式，例如时间日期插件在时尚模式下
        // 把时间和日期并排显示成一行
        DockCompositor.fashionMode = Qt.binding(function(){
            return dock.fashionDock.enabled
        })

        DockCompositor.panelScale = Qt.binding(function(){
            return Panel.devicePixelRatio
        })

        DockCompositor.moveXEmbedWindowHandler = function(wid, dx, dy, anchorWindow) {
            return Panel.moveXEmbedWindow(wid, dx, dy, anchorWindow)
            // If true: result arrives asynchronously via Panel.xembedWindowMoveResult signal
            // If false: pre-check failed, caller should notify failure immediately
        }

        Panel.xembedWindowMoveResult.connect(function(wid, success) {
            DockCompositor.notifyXEmbedWindowMoveResult(wid, success)
        })

        dock.itemIconSizeBase = dock.dockItemMaxSize
        changeDragAreaAnchor()
        if (!fashionDock.enabled)
            finishInitialization()
        else
            Qt.callLater(finishInitialization)
    }
}

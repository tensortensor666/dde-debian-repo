#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Waylib::WaylibServer" for configuration "None"
set_property(TARGET Waylib::WaylibServer APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Waylib::WaylibServer PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Qml;Qt6::Core;Qt6::Gui;Qt6::Quick"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwaylibserver.so.0.6.13"
  IMPORTED_SONAME_NONE "libwaylibserver.so.0"
  )

list(APPEND _cmake_import_check_targets Waylib::WaylibServer )
list(APPEND _cmake_import_check_files_for_Waylib::WaylibServer "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwaylibserver.so.0.6.13" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

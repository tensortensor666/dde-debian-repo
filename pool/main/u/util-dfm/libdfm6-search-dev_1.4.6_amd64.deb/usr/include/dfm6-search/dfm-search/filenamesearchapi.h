// SPDX-FileCopyrightText: 2025 - 2026 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef FILENAMESEARCHAPI_H
#define FILENAMESEARCHAPI_H

#include <dfm-search/dsearch_global.h>
#include <dfm-search/searchoptions.h>
#include <dfm-search/searchresult.h>

DFM_SEARCH_BEGIN_NS

/**
 * @brief The FileNameOptionsAPI class provides file name search specific options
 *
 * This class extends the base SearchOptions with file name search specific settings,
 * such as pinyin search and file type filtering.
 */
class FileNameOptionsAPI
{
public:
    /**
     * @brief Constructor
     * @param options The SearchOptions object to operate on
     */
    explicit FileNameOptionsAPI(SearchOptions &options);

    /**
     * @brief Enable or disable pinyin search
     * @param enabled true to enable pinyin search, false to disable
     */
    void setPinyinEnabled(bool enabled);

    /**
     * @brief Check if pinyin search is enabled
     * @return true if pinyin search is enabled, false otherwise
     */
    bool pinyinEnabled() const;

    /**
     * @brief Enable or disable pinyin acronym search
     * @param enabled true to enable pinyin acronym search, false to disable
     */
    void setPinyinAcronymEnabled(bool enabled);

    /**
     * @brief Check if pinyin acronym search is enabled
     * @return true if pinyin acronym search is enabled, false otherwise
     */
    bool pinyinAcronymEnabled() const;

    /**
     * @brief Set file type filters
     * @param types List of file types to include in search
     *
     * Supported file types:
     * - app: Application files
     * - archive: Archive files
     * - audio: Audio files
     * - doc: Document files
     * - pic: Picture files
     * - video: Video files
     * - dir: folder
     * - other: other files
     */
    void setFileTypes(const QStringList &types);

    /**
     * @brief Get the current file type filters
     * @return List of file types
     */
    QStringList fileTypes() const;

    /**
     * @brief Set file extension filters
     * @param extensions List of file extensions to include in search
     * 
     * Example: "txt", "pdf", "docx"
     */
    void setFileExtensions(const QStringList &extensions);

    /**
     * @brief Get the current file extension filters
     * @return List of file extensions
     */
    QStringList fileExtensions() const;

private:
    SearchOptions &m_options;
};

/**
 * @brief The FileNameResultAPI class provides file name search specific result handling
 *
 * This class extends the base SearchResult with file name search specific features,
 * such as file size, modification time, and file type information.
 *
 * When detailed results are enabled, this API provides access to all indexed fields
 * including filename, extension, hidden status, and both modification and birth times.
 */
class FileNameResultAPI
{
public:
    /**
     * @brief Constructor
     * @param result The SearchResult object to operate on
     */
    explicit FileNameResultAPI(SearchResult &result);

    // ==================== Basic Attributes ====================

    /**
     * @brief Get the file size
     * @return The file size as formatted string
     */
    QString size() const;

    /**
     * @brief Set the file size
     * @param size The file size as formatted string
     */
    void setSize(const QString &size);

    /**
     * @brief Get the file modification time (legacy, use modifyTimeString instead)
     * @return The modification time as formatted string
     * @deprecated Use modifyTimeString() for formatted string or modifyTimestamp() for raw timestamp
     */
    QString modifiedTime() const;

    /**
     * @brief Set the file modification time (legacy)
     * @param time The modification time as formatted string
     * @deprecated Use setModifyTimestamp() instead
     */
    void setModifiedTime(const QString &time);

    /**
     * @brief Check if the result is a directory
     * @return true if the result is a directory, false otherwise
     */
    bool isDirectory() const;

    /**
     * @brief Set whether the result is a directory
     * @param isDir true if the result is a directory, false otherwise
     */
    void setIsDirectory(bool isDir);

    /**
     * @brief Get the file type
     * @return The file type as string
     */
    QString fileType() const;

    /**
     * @brief Set the file type
     * @param type The file type to set
     */
    void setFileType(const QString &type) const;

    // ==================== Extended Attributes ====================

    /**
     * @brief Get the file name (without path)
     * @return The file name
     */
    QString filename() const;

    /**
     * @brief Set the file name
     * @param name The file name to set
     */
    void setFilename(const QString &name);

    /**
     * @brief Get the file extension
     * @return The file extension (lowercase, without dot)
     */
    QString fileExtension() const;

    /**
     * @brief Set the file extension
     * @param ext The file extension to set
     */
    void setFileExtension(const QString &ext);

    /**
     * @brief Check if the file is hidden
     * @return true if the file is hidden, false otherwise
     */
    bool isHidden() const;

    /**
     * @brief Set whether the file is hidden
     * @param hidden true if the file is hidden, false otherwise
     */
    void setIsHidden(bool hidden);

    // ==================== Modification Time ====================

    /**
     * @brief Set the modification time timestamp
     * @param timestamp Unix timestamp in seconds
     */
    void setModifyTimestamp(qint64 timestamp);

    /**
     * @brief Get the modification time timestamp
     * @return Unix timestamp in seconds, 0 if not set
     */
    qint64 modifyTimestamp() const;

    /**
     * @brief Get the modification time as a formatted string
     * @return Formatted time string (yyyy-MM-dd HH:mm:ss)
     */
    QString modifyTimeString() const;

    // ==================== Birth/Creation Time ====================

    /**
     * @brief Set the birth/creation time timestamp
     * @param timestamp Unix timestamp in seconds
     */
    void setBirthTimestamp(qint64 timestamp);

    /**
     * @brief Get the birth/creation time timestamp
     * @return Unix timestamp in seconds, 0 if not set
     */
    qint64 birthTimestamp() const;

    /**
     * @brief Get the birth/creation time as a formatted string
     * @return Formatted time string (yyyy-MM-dd HH:mm:ss)
     */
    QString birthTimeString() const;

    // ==================== File Size (Numeric) ====================

    /**
     * @brief Set the file size in bytes
     * @param bytes File size in bytes
     */
    void setFileSizeBytes(qint64 bytes);

    /**
     * @brief Get the file size in bytes
     * @return File size in bytes, 0 if not set
     */
    qint64 fileSizeBytes() const;

    // ==================== Pinyin (filename index) ====================

    /**
     * @brief Get the pinyin (full spelling) of the file name
     * @return Pinyin string, empty if not stored in the index
     */
    QString pinyin() const;

    /**
     * @brief Set the pinyin (full spelling) of the file name
     * @param pinyin The pinyin string
     */
    void setPinyin(const QString &pinyin);

    /**
     * @brief Get the pinyin acronym (initials) of the file name
     * @return Pinyin acronym string, empty if not stored in the index
     */
    QString pinyinAcronym() const;

    /**
     * @brief Set the pinyin acronym (initials) of the file name
     * @param acronym The pinyin acronym string
     */
    void setPinyinAcronym(const QString &acronym);

private:
    SearchResult &m_result;
};

DFM_SEARCH_END_NS

#endif   // FILENAMESEARCHAPI_H

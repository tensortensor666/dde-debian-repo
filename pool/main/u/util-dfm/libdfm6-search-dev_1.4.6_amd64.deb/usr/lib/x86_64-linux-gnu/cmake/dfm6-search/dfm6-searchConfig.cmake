include(CMakeFindDependencyMacro)

# 添加必要的依赖
find_dependency(Qt6 COMPONENTS Core)
find_dependency(Dtk6 COMPONENTS Core)
find_dependency(Threads)
find_package(Boost REQUIRED)

if (Boost_VERSION_STRING VERSION_LESS "1.89.0")
    message(STATUS "Boost < 1.89 → using Boost::system")
    find_package(Boost REQUIRED COMPONENTS system)
endif()

# 查找 PkgConfig 和 liblucene++ 依赖
find_dependency(PkgConfig)
if(PkgConfig_FOUND)
    pkg_check_modules(Lucene REQUIRED IMPORTED_TARGET liblucene++ liblucene++-contrib)
endif()

set(dfm6-search_INCLUDE_DIR /usr/include/dfm6-search)
set(dfm6-search_LIBRARIES dfm6-search)

if(NOT TARGET dfm6-search)
    include("${CMAKE_CURRENT_LIST_DIR}/dfm6-searchTargets.cmake")
endif()

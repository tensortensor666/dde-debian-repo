#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dfm6-search" for configuration "None"
set_property(TARGET dfm6-search APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(dfm6-search PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdfm6-search.so.1.4.6"
  IMPORTED_SONAME_NONE "libdfm6-search.so.1"
  )

list(APPEND _cmake_import_check_targets dfm6-search )
list(APPEND _cmake_import_check_files_for_dfm6-search "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdfm6-search.so.1.4.6" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

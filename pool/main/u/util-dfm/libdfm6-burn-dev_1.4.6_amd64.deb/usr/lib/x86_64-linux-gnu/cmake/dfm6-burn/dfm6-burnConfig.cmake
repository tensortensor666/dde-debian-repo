set(dfm6-burn_INCLUDE_DIR /usr/include/dfm6-burn)
set(dfm6-burn_LIBRARIES dfm6-burn)
include_directories("${dfm6-burn_INCLUDE_DIR}")

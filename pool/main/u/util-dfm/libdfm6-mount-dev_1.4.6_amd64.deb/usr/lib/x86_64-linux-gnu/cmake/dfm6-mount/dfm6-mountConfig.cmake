set(dfm6-mount_INCLUDE_DIR /usr/include/dfm6-mount)
set(dfm6-mount_LIBRARIES dfm6-mount)
include_directories("${dfm6-mount_INCLUDE_DIR}")

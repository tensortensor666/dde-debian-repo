set(dfm6-io_INCLUDE_DIR /usr/include/dfm6-io)
set(dfm6-io_LIBRARIES dfm6-io)
include_directories("${dfm6-io_INCLUDE_DIR}")
